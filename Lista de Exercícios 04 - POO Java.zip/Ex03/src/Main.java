import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Cliente> clientesList = new ArrayList<>();

        clientesList.add(new Cliente("João", 18, LocalDate.of(2025, 12, 13)));
        clientesList.add(new Cliente("Maria", 19, LocalDate.of(2023, 10, 12)));
        clientesList.add(new Cliente("Pedro", 20, LocalDate.of(2020, 5, 20)));
        clientesList.add(new Cliente("Julia", 22, LocalDate.of(2022, 6, 3)));
        clientesList.add(new Cliente("Luiz", 23, LocalDate.of(2024, 10, 15)));
        clientesList.add(new Cliente("Ana", 24, LocalDate.of(2019, 11, 25)));

        Set<Cliente> cadastroMaior5Anos = clientesList.stream()
                .filter(cliente -> cliente.getDataCadastro().isBefore(LocalDate.of(2021, 1, 1)))
                .collect(Collectors.toSet());

        System.out.println("\nClientes com cadastro maiores de 5 anos");
        for (Cliente c : cadastroMaior5Anos) {
            System.out.println("Nome: " + c.getNome() + " | Idade: " + c.getIdade() + " | Data da Cadastro: " + c.getDataCadastro());
        }

    }
}