import java.time.LocalDate;

public class Cliente extends Pessoa {
    private String nome;
    private int idade;
    private LocalDate dataCadastro;

    public Cliente(String nome, int idade, LocalDate dataCadastro) {
        super(nome, idade);
        this.dataCadastro = dataCadastro;
    }

    public LocalDate getDataCadastro() {
        return dataCadastro;
    }

}
