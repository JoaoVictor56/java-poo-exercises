import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Produto> produtoList = new ArrayList<>();

        produtoList.add(new Produto("Computador Pichau Gamer", 150, 2999.80));
        produtoList.add(new Produto("Monitor", 600, 589.69));
        produtoList.add(new Produto("Mouse", 300, 87.35));
        produtoList.add(new Produto("Headset", 260, 149.99));
        produtoList.add(new Produto("Teclado", 125, 260.64));
        produtoList.add(new Produto("Mousepad", 700, 49.89));
        produtoList.add(new Produto("Microfone", 200, 367.29));

        Set<Produto> quantidadeEstoqueMaiorQue0 = produtoList.stream()
                .filter(produto -> produto.getQuantidadeEstoque() > 0)
                .sorted(Comparator.comparingDouble(Produto::getQuantidadeEstoque))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        System.out.println("\nProdutos em estoque");
        for(Produto produto : quantidadeEstoqueMaiorQue0) {
            System.out.println("Nome: " + produto.getNome() + " | Quantidade: " + produto.getQuantidadeEstoque() + " | Preço: " + produto.getPreco());
        }

    }
}