public class Produto extends ProdutoBase {
    private String nome;
    private int quantidadeEstoque;
    private double preco;

    public Produto(String nome, int quantidade, double preco) {
        super(nome, quantidade);
        this.preco = preco;
    }

    public double getPreco() {
        return preco;
    }
}
