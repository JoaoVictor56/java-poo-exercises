public abstract class ProdutoBase implements Entidade {
    private String nome;
    private int quantidadeEstoque;

    public ProdutoBase(String nome, int quantidade) {
        this.nome = nome;
        this.quantidadeEstoque = quantidade;
    }

    @Override
    public String getNome() {
        return nome;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }


}
