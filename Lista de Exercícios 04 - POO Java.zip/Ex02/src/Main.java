import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Funcionario> funcionarioList = new ArrayList<>();

        funcionarioList.add(new Funcionario("João", 18, 1500));
        funcionarioList.add(new Funcionario("Maria", 19, 2000));
        funcionarioList.add(new Funcionario("Pedro", 20, 3600));
        funcionarioList.add(new Funcionario("Julia", 21, 5600));
        funcionarioList.add(new Funcionario("Luiz", 22, 5500));
        funcionarioList.add(new Funcionario("Ana", 23, 6000));

        Set<Funcionario> salarioMaior5000 = funcionarioList.stream()
                .filter(funcionario -> funcionario.getSalario() > 5000)
                .sorted(Comparator.comparingDouble(Funcionario::getSalario).reversed())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        System.out.println("\nFuncionários com salário acima de R$5000");
        for (Funcionario funcionario : salarioMaior5000) {
            System.out.println("Nome: " + funcionario.getNome() + " | Idade: " + funcionario.getIdade() + " | Salário" + funcionario.getSalario());
        }
    }

}