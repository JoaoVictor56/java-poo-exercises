import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Funcionario> funcionarios = new ArrayList<>();

        //Adiciona funcionários à lista
        funcionarios.add(new Funcionario("João", 18, 1500.00, "FIN."));
        funcionarios.add(new Funcionario("Maria", 18, 4998.03, "TI"));
        funcionarios.add(new Funcionario("Pedro", 18, 2500.90, "ADM."));
        funcionarios.add(new Funcionario("Julia", 18, 5600.68, "FIN."));
        funcionarios.add(new Funcionario("Luiz", 18, 2530.66, "RH"));
        funcionarios.add(new Funcionario("Ana", 18, 6500.39, "TI"));

        //Filtragem
        Map<String, List<Funcionario>> agrupados = funcionarios.stream()
                .filter(funcionario -> funcionario.getSalario() > 2000 && funcionario.getSalario() < 5000)
                .collect(Collectors.groupingBy(Funcionario::getDepartamento));

        //Exibe os resultados
        agrupados.forEach((depto, lista) -> {
            System.out.println("Departamento: " + depto);
            lista.forEach(funcionario -> System.out.println("Nome: " + funcionario.getNome() + " | Salario: R$" + funcionario.getSalario()));
        });
    }
}