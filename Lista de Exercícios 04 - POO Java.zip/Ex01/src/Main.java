import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Cliente> clientes = new ArrayList<>();

        clientes.add(new Cliente("João", 18));
        clientes.add(new Cliente("Maria", 19));
        clientes.add(new Cliente("Pedro", 20));
        clientes.add(new Cliente("Julia", 65));
        clientes.add(new Cliente("Luiz", 42));
        clientes.add(new Cliente("Ana", 31));

        Set<Cliente> clientesMaiores30 = clientes.stream()
                .filter(cliente -> cliente.getIdade() > 30)
                .collect(Collectors.toSet());

        System.out.println("\nClientes maiores que 30 anos");
        for (Cliente c : clientesMaiores30) {
            System.out.println("Nome: " + c.getNome() + " | " + "Idade: " + c.getIdade());
        }
    }
}