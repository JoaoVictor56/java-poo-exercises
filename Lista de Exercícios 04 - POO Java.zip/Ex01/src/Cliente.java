public class Cliente extends Pessoa {
    public Cliente(String name, int age) {
        super(name, age);
    }
}
