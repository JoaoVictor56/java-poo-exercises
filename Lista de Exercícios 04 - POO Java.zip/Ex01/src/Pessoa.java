public abstract class Pessoa implements Entidade {
    private String nome;
    private int idade;

    public Pessoa(String name, int age) {
        this.nome = name;
        this.idade = age;
    }

    @Override
    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
}
