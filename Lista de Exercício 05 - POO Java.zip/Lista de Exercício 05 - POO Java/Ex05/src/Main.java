/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 02/03/2025
 * Objetivo:Criar uma Hierarquia de Produtos e Filtrar por Preço
 */

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Produto> produto = new ArrayList<>();

        produto.add(new Produto("Notebook", 3500.0));
        produto.add(new Produto("Mouse", 150.0));
        produto.add(new Produto("Teclado", 300.0));
        produto.add(new Produto("Monitor", 1200.0));

        List<Double> precos = produto.stream()
                .map(Produto::getPreco)
                .toList();

        double soma = produto.stream()
                .collect(Collectors.summingDouble(Produto::getPreco));

        double media = produto.stream()
                .collect(Collectors.averagingDouble(Produto::getPreco));

        System.out.println("\nLista de preços: " + precos);
        System.out.println("Soma total.....: " + soma);
        System.out.println("Média de preços: " + media);
    }
}