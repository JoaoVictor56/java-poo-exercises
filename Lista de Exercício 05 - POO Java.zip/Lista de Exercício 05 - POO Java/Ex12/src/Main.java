import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Funcionario> funcionario = new ArrayList<>();

        funcionario.add(new Funcionario("João", 4500.0, "TI"));
        funcionario.add(new Funcionario("Maria", 5600, "TI"));
        funcionario.add(new Funcionario("Pedro", 3500.0, "RH"));
        funcionario.add(new Funcionario("Julia", 4500.0, "RH"));
        funcionario.add(new Funcionario("Mario", 7500.0, "ADM"));
        funcionario.add(new Funcionario("Ana", 7600.0, "ADM"));

        List<Funcionario> funcionariosTI = funcionario.stream()
                .filter(f -> f.getDepartamento().equalsIgnoreCase("TI"))
                .toList();

        Map<String, Double> aumento = funcionario.stream()
                .map(f -> new Funcionario(
                        f.getNome(),
                        f.salario() * 1.1,
                        f.getDepartamento()
                ))
                .collect(Collectors.groupingBy(
                        Funcionario::getDepartamento,
                        Collectors.summingDouble(Funcionario::salario)
                ));

        System.out.println("\n=-=-=|Informações Funcionários|=-=-=");
        for(Funcionario funcionario1 : funcionariosTI) {
            System.out.format("Nome: %s | Salário: %.2f | Departamento: %s\n", funcionario1.getNome(), funcionario1.salario(), funcionario1.getDepartamento());
        }

        System.out.println("Total de salários por departamento: " + aumento);

    }
}