/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 04/03/2025
 * Objetivo:Criar uma Hierarquia de Produtos e Filtrar por Preço
 */

public class Funcionario {
    private String nome;
    private double salario;
    private String departamento;

    public Funcionario(String nome, double salario, String departamento) {
        this.nome = nome;
        this.salario = salario;
        this.departamento = departamento;
    }

    public String getNome() {
        return nome;
    }

    public double salario() {
        return salario;
    }

    public String getDepartamento() {
        return departamento;
    }
}
