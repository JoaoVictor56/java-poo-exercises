/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 03/03/2025
 * Objetivo:
 */

import javax.swing.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Vendedor> vendedor = new ArrayList<>();

        vendedor.add(new Vendedor("João", 18000.0));
        vendedor.add(new Vendedor("Maria", 28000.0));
        vendedor.add(new Vendedor("Pedro", 8000.0));
        vendedor.add(new Vendedor("Julia", 12000.0));
        vendedor.add(new Vendedor("Mario", 15000.0));
        vendedor.add(new Vendedor("Ana", 19000.0));

        List<Vendedor> maiorQueDezMil = vendedor.stream()
                .filter(v -> v.getTotalVendas() > 10000)
                .toList();

        Optional<Vendedor> maiorVenda = vendedor.stream()
                .collect(Collectors.maxBy(
                        Comparator.comparing(Vendedor::getTotalVendas)
                ));

        Optional<Vendedor> menorVenda = vendedor.stream()
                .collect(Collectors.minBy(
                        Comparator.comparing(Vendedor::getTotalVendas)
                ));

        List<String> nomes = vendedor.stream()
                        .map(Vendedor::getNome)
                                .toList();

        System.out.println("\n=-=-=|Vendas acima de R$10000|=-=-=");
        for (Vendedor maiorDez : maiorQueDezMil) {
            System.out.format("Nome: %-5s | Valor de vendas: R$%.2f\n", maiorDez.getNome(), maiorDez.getTotalVendas());
        }

        System.out.println("\n=-=-=|Melhor Vendedor|=-=-=");
        System.out.println(maiorVenda.get());

        System.out.println("\n=-=-=|Pior Vendedor|=-=-=");
        System.out.println(menorVenda.get());

        System.out.println("\n=-=-=|Nomes dos vendedores|=-=-=");
        System.out.println(nomes);
    }
}