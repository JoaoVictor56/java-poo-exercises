/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 01/03/2025
 * Objetivo: 
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Funcionario> funcionario = new ArrayList<>();

        funcionario.add(new Funcionario("João", 18, "TI", 1621));
        funcionario.add(new Funcionario("Maria", 18, "TI", 1621));
        funcionario.add(new Funcionario("Pedro", 18, "RH", 2214));
        funcionario.add(new Funcionario("Ana", 18, "RH", 2250));
        funcionario.add(new Funcionario("Mario", 18, "ADM", 5604));

        Map<String, List<Funcionario>> cargoFuncionario = funcionario.stream()
                .collect(Collectors.groupingBy(Funcionario::getCargo));

        List<String> nomeFuncionario = funcionario.stream()
                .map(Funcionario::getNome)
                .toList();

        Map<String, Double> mediaSalario = funcionario.stream()
                .collect(Collectors.groupingBy(
                        Funcionario::getCargo,
                        Collectors.averagingDouble(Funcionario::getSalario)
                ));

        System.out.println();
        //System.out.println(cargoFuncionario);

        System.out.println("\n=-=-=|Cargos preenchidos|=-=-=");
        for (String func : cargoFuncionario.keySet()) {
            System.out.println("Cargo dos funcionários: " + func);
        }

        System.out.println("\n=-=-=|Lista de funcionários|=-=-=");
        for (String func : nomeFuncionario) {
            System.out.println("Nome dos funcionarios: " + func);
        }

        System.out.println("\n=-=-=|Média de salário por cargo|=-=-=");
        System.out.println(mediaSalario);

    }
}