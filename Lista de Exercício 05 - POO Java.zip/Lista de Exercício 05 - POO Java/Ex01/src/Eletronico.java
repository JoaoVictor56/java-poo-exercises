public class Eletronico extends ItemLoja {
    public Eletronico(int id, String nome, double preco) {
        super(id, nome, preco);
    }
}
