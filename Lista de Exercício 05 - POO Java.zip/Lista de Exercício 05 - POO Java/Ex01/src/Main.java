/*
* Aluno...: João Victor Rantin Silvério
* RA......: 252657-2024
* Data....: 01/03/2025
* Objetivo:Criar uma Hierarquia de Produtos e Filtrar por Preço
*/

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        List<Eletronico> eletronicos = new ArrayList<>();
        List<Roupa> roupas = new ArrayList<>();

        eletronicos.add(new Eletronico(1, "Computador TGT Gamer", 1589.59));
        eletronicos.add(new Eletronico(2, "Mouse Gamer TGT", 59.60));
        eletronicos.add(new Eletronico(3, "Teclado Gamer TGT, Switch Azul", 89.99));
        eletronicos.add(new Eletronico(4, "Headset Gamer TGT", 79.36));
        eletronicos.add(new Eletronico(5, "Monitor Gamer TGT", 550.68));

        roupas.add(new Roupa(1, "Camiseta azul", 15.99));
        roupas.add(new Roupa(1, "Calça jeans preta", 169.69));
        roupas.add(new Roupa(1, "Camiseta verde", 15.99));
        roupas.add(new Roupa(1, "Calça jeans azul", 263.96));

        List<Eletronico> eletronicosMaiorQue100 = eletronicos.stream()
                .filter(elet -> elet.getPreco() > 100.00)
                .toList();

        List<Roupa> roupasMaiorQue100 = roupas.stream()
                .filter(roup -> roup.getPreco() > 100)
                .toList();


        System.out.println("\n=-=-=|Eletronicos maiores que R$100|=-=-=");
        for (Eletronico eletronico : eletronicosMaiorQue100) {
            System.out.format("Produto: %s | ID: %d | Preço: R$%.2f\n", eletronico.getNome(), eletronico.getID(), eletronico.getPreco());
        }

        System.out.println("\n=-=-=|Roupas maiores que R$100|=-=-=");
        for (Roupa roupa : roupasMaiorQue100) {
            System.out.format("Produto: %s | ID: %d | Preço: R$%.2f\n", roupa.getNome(), roupa.getID(), roupa.getPreco());
        }

    }
}
