public class Roupa extends ItemLoja {
    public Roupa(int id, String nome, double preco) {
        super(id, nome, preco);
    }
}
