/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 01/03/2025
 * Objetivo:
 */

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Aluno> aluno = new ArrayList<>();

        aluno.add(new Aluno("João", 9.2, 17));
        aluno.add(new Aluno("Maria", 10.0, 18));
        aluno.add(new Aluno("Pedro", 5.8, 19));
        aluno.add(new Aluno("Ana", 8.3, 20));
        aluno.add(new Aluno("Mario", 2.6, 21));

        List<String> alunoList = aluno.stream()
                .filter(nota -> nota.getNota() >= 7.0)
                .sorted(Comparator.comparing(Aluno::getNota).reversed()
                        .thenComparing(Aluno::getIdade))
                .map(Aluno::getNome)
                .toList();

        for (String a : alunoList) {
            System.out.println("Nome do aluno com nota maior que 7: " + a);
        }

    }
}