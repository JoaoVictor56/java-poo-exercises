public class PedidoDTO {

    private int id;
    private double valorTotal;

    public PedidoDTO(int id, double valorTotal) {
        this.id = id;
        this.valorTotal = valorTotal;
    }

    public int getID() {
        return id;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Valor Total: R$" + valorTotal;
    }
}