/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 02/03/2025
 * Objetivo:
 */

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Pedido> pedido = new ArrayList<>();

        pedido.add(new Pedido(1, "João", 1820.89));
        pedido.add(new Pedido(2, "Maria", 501.90));
        pedido.add(new Pedido(3, "Pedro", 639.85));
        pedido.add(new Pedido(4, "Ana",  2574.3));
        pedido.add(new Pedido(5, "Mario",  200.60));

        List<PedidoDTO> dtoList = pedido.stream()
                .map(p -> new PedidoDTO(p.getID(), p.getValorTotal()))
                .toList();

        //System.out.println(dtoList);

        System.out.println("\n=-=-=|Valores dos produtos|=-=-=");
        for (PedidoDTO dto : dtoList) {
            System.out.format("ID: %d | Valor Total: %.2f\n",dto.getID(), dto.getValorTotal());
        }
    }
}