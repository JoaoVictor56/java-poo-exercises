public class Pedido {

    private int id;
    private String cliente;
    private double valorTotal;

    public Pedido(int id, String cliente, double valorTotal) {
        this.id = id;
        this.cliente = cliente;
        this.valorTotal = valorTotal;
    }

    public int getID() {
        return id;
    }

    public String getCliente() {
        return cliente;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    @Override
    public String toString() {
        return "ID:" + id + " | Cliente: " + cliente + " | Valor total: R$" + valorTotal;
    }
}