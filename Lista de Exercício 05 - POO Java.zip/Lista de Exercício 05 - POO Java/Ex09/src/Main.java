/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 03/03/2025
 * Objetivo:
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Produto> produto = new ArrayList<>();

        produto.add(new Produto(1, "Notebook", 3500.0));
        produto.add(new Produto(2, "Mouse", 150.0));
        produto.add(new Produto(3, "Monitor", 350.0));
        produto.add(new Produto(4, "Teclado", 200.0));

        Map<Integer, Produto> produtoMap = produto.stream()
                .collect(Collectors.toMap(Produto::getId, p -> p));


        System.out.println("=-=-=|Lista de produtos|=-=-=");
        System.out.println(produtoMap);

        Produto produtoProcurado = produtoMap.get(2);
        System.out.println("\n=-=-=|Produto procurado|=-=-=");
        System.out.println(produtoProcurado);
    }
}