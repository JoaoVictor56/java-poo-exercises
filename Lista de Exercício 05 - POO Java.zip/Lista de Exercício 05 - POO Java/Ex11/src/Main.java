/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 03/03/2025
 * Objetivo:
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Pedido> pedido = new ArrayList<>();

        pedido.add(new Pedido(1, "João", "Pendente"));
        pedido.add(new Pedido(2, "Maria", "Pago"));
        pedido.add(new Pedido(3, "Pedro", "cancelado"));
        pedido.add(new Pedido(4, "Julia", "Pago"));
        pedido.add(new Pedido(5, "Mario", "Pago"));
        pedido.add(new Pedido(6, "Ana", "Cancelado"));

        List<Pedido> pago = pedido.stream()
                .filter(p -> p.getStatus().equals("Pago"))
                .toList();

        Map<String, List<Pedido>> agrupadoPorStatus = pedido.stream()
                .collect(Collectors.groupingBy(Pedido::getStatus));

        for (Pedido pagado : pago) {
            System.out.format("Id: %d | Cliente: %s | Status: %s\n", pagado.getId(), pagado.getCliente(), pagado.getStatus());
        }

        System.out.println("\nAgrupados por status: " + agrupadoPorStatus);
    }
}