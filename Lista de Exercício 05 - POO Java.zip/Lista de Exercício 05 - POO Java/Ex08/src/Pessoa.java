public class Pessoa implements Descritivel {
    private String nome;
    private int idade;

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    @Override
    public String getDecisao() {
        return nome + " (idade: " + idade + " anos)";
    }
}
