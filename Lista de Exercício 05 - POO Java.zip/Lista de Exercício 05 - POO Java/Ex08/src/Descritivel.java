public interface Descritivel {
    public String getDecisao();
}
