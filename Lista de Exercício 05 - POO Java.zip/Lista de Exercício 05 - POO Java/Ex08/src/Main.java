/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 03/03/2025
 * Objetivo:
 */

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Pessoa> pessoa = new ArrayList<>();

        pessoa.add(new Pessoa("João", 18));
        pessoa.add(new Pessoa("Maria", 19));
        pessoa.add(new Pessoa("Pedro", 20));
        pessoa.add(new Pessoa("Julia", 21));
        pessoa.add(new Pessoa("Mario", 20));
        pessoa.add(new Pessoa("Luzia", 63));

        List<String> descricao = pessoa.stream()
                .map(Pessoa::getDecisao)
                .toList();

        String textoConcatenado = pessoa.stream()
                .map(Pessoa::getDecisao)
                .collect(Collectors.joining(", "));

        System.out.println("\n=-=-=|Texto descrição|=-=-=");
        System.out.println(descricao);

        System.out.println("\n=-=-=|Texto Concatenado|=-=-=");
        System.out.println(textoConcatenado);
    }
}