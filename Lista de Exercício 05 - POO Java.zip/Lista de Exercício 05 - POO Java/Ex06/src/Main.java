/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 03/03/2025
 * Objetivo:
 */

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Cliente> cliente = new ArrayList<>();

        cliente.add(new Cliente("João", 25));
        cliente.add(new Cliente("Maria", 17));
        cliente.add(new Cliente("Pedro", 32));
        cliente.add(new Cliente("Julia", 40));
        cliente.add(new Cliente("Mario", 29));
        cliente.add(new Cliente("Ana", 16));

        List<Cliente> maiorDeIdade = cliente.stream()
                .filter(c -> c.getIdade() > 18)
                .toList();

        long maiorQue30 = cliente.stream()
                .filter(c -> c.getIdade() > 30)
                .count();

        List<String> nomes = cliente.stream()
                .map(Cliente::getNome)
                .toList();

        System.out.println("\n=-=-=|Clientes maiores de idade|=-=-=");
        for(Cliente clie : maiorDeIdade) {
            System.out.format("Nome: %-5s | Idade %d anos\n", clie.getNome(), clie.getIdade());
        }

        System.out.println("\nQuantidade com mais de 30 anos: " + maiorQue30);
        System.out.println("Lista de clientes.............: " + nomes);
    }
}