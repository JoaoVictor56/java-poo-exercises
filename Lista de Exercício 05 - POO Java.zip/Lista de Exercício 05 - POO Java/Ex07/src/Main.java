/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 03/03/2025
 * Objetivo:
 */

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Produto> produto = new ArrayList<>();

        produto.add(new Produto("Notebook", 3500.0));
        produto.add(new Produto("Mouse", 150.0));
        produto.add(new Produto("Teclado", 300.0));
        produto.add(new Produto("Monitor", 1200.0));

        Optional<Produto> maisCaro = produto.stream()
                .collect(Collectors.maxBy(
                        Comparator.comparing(Produto::getPreco)
                ));

        Optional<Produto> maisBarato = produto.stream()
                .collect(Collectors.minBy(
                        Comparator.comparing(Produto::getPreco)
                ));

        System.out.println("\n=-=-=|Produto mais caro|=-=-=");
        System.out.println(maisCaro.get());

        System.out.println("\n=-=-=|Produto mais barato|=-=-=");
        System.out.println(maisBarato.get());

        List<String> nomes = produto.stream()
                .map(Produto::getNome)
                .toList();

        System.out.println("\n=-=-=|Lista de produtos|=-=-=");
        System.out.println(nomes);
    }
}