/*
 * Aluno...: João Victor Rantin Silvério
 * RA......: 252657-2024
 * Data....: 04/03/2025
 * Objetivo:Criar uma Hierarquia de Produtos e Filtrar por Preço
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Livro> livro = new ArrayList<>();

        livro.add(new Livro("O Programador Pragmático", "Andy Hunt e Dave Thomas", 200.20));
        livro.add(new Livro("Entendendo Algoritimos", "Aditya Y. Bhargava", 56.25));
        livro.add(new Livro("The Art of Computer Programming", "Donald E. Knuth", 434.60));
        livro.add(new Livro("Sistemas Operacionais Modernos", "Andrew Stuart Tanenbaum", 305.90));
        livro.add(new Livro("Arquitetura e Organização de Computadores", "Willian Stallings", 242.74));

        //Ordena em ordem crescente por preço
        List<Livro> ordemCrescentePreco = livro.stream()
                .sorted(Comparator.comparing(Livro::getPreco))
                .toList();

        //Ordena por ordem alfabética
        List<Livro> ordemAlfabeticaAutor = livro.stream()
                .sorted(Comparator.comparing(Livro::getAutor))
                .toList();

        //Lista de nomes
        List<String> listaNomes = livro.stream()
                        .map(Livro::getTitulo)
                                .toList();

        //Texto concatenado
        String textoConcatenado = livro.stream()
                        .map(Livro::getTitulo)
                        .collect(Collectors.joining(" | "));

        //Imprime os valores (ordem crescente por preço)
        System.out.println("\n=-=-=|Livros ordenados por preços (ordem crescente)|=-=-=");
        for (Livro ordemPreco : ordemCrescentePreco) {
            System.out.format("Título: %s | Autor: %s | Preço: R$%.2f\n", ordemPreco.getTitulo(), ordemPreco.getAutor(), ordemPreco.getPreco());
        }

        //Imprime os valores (ordem alfabética por autor)
        System.out.println("\n=-=-=|Livros ordenados por autores (ordem alfabética)|=-=-=");
        for (Livro ordemAutor : ordemAlfabeticaAutor) {
            System.out.format("Título: %s | Autor: %s | Preço: R$%.2f\n", ordemAutor.getTitulo(), ordemAutor.getAutor(), ordemAutor.getPreco());
        }

        //Imprime os valores (lista de nomes)
        System.out.println("\n=-=-=|Lista de livros|=-=-=");
        for(String nomes : listaNomes) {
            System.out.format("Lista de livros: %s\n", nomes);
        }

        //Imprime o texto concatenado
        System.out.println("\nTexto concatenado: " + textoConcatenado);

    }
}