import Ex22.Pessoa;

void main() {
    List<Pessoa> pessoaList = List.of(
            new Pessoa("João", LocalDate.of(2007, 12, 13)),
            new Pessoa("Maria", LocalDate.of(2000, 3, 16)),
            new Pessoa("Pedro", LocalDate.of(2007, 6, 24)),
            new Pessoa("Ana", LocalDate.of(1998, 5, 7)),
            new Pessoa("André", LocalDate.of(1981, 2, 16)),
            new Pessoa("Vanessa", LocalDate.of(1982, 6, 12)),
            new Pessoa("Mario", LocalDate.of(1971, 1, 1))
    );

    Map<Integer, List<String>> mapa = new HashMap<>();

    for (Pessoa p : pessoaList) {
        int idade = p.getIdade();
        mapa.putIfAbsent(idade, new ArrayList<>());
        mapa.get(idade).add(p.getNome());
    }

    mapa.forEach((i, s) -> {
        IO.println("Nome: " + s + " (" + i + " anos)");
    });

}
