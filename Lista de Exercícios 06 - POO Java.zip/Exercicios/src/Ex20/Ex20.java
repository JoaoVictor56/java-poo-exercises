import Ex20.Usuario;

void main() {
    List<Usuario> userList = new ArrayList<>();

    userList.add(new Usuario("João"));
    userList.add(new Usuario("Maria"));
    userList.add(new Usuario("Francisco"));
    userList.add(new Usuario("Ana"));

    Map<String, Usuario> userToMap = userList.stream()
            .collect(Collectors.toMap(
                    Usuario::getNome,
                    usuario -> usuario));

    userToMap.forEach((l, usuario) -> {
        System.out.println(l);
    });

}
