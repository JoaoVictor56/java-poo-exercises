package Ex12;

public class ResumoPessoa {
    private String nomeCompleto;
    private String faixaEtaria;

    public ResumoPessoa(String nomeCompleto, String faixaEtaria) {
        this.nomeCompleto = nomeCompleto;
        this.faixaEtaria = faixaEtaria;
    }

    @Override
    public String toString() {
        return String.format("Resumo[Nome: %s | Faixa: %s]", nomeCompleto, faixaEtaria);
    }
}
