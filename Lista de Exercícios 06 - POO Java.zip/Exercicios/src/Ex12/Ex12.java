import Ex12.Pessoa;
import Ex12.ResumoPessoa;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

void main () {
        List<Pessoa> pessoas = Arrays.asList(
            new Pessoa("Joao", 15),
            new Pessoa("Maria", 25),
            new Pessoa("Carlos", 70),
            new Pessoa("Ana", 10)
        );

        List<ResumoPessoa> resumos = pessoas.stream()
            .map(p -> {
                String faixa = (p.getIdade() < 18) ? "Menor de Idade" : 
                               (p.getIdade() < 60) ? "Adulto" : "Idoso";
                
                return new ResumoPessoa(p.getNome().toUpperCase(), faixa);
            })
            .collect(Collectors.toList());
 
        resumos.forEach(System.out::println);
}
