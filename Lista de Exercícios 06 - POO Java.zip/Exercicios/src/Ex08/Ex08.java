import Ex08.Usuario;

void main() {
    //Lista principal
    List<Usuario> usuarioList = new ArrayList<>();

    //Adicionando elementos à lista
    usuarioList.add(new Usuario(1, "João"));
    usuarioList.add(new Usuario(2, "Maria"));
    usuarioList.add(new Usuario(3, "Pedro"));
    usuarioList.add(new Usuario(4, "Mario"));
    usuarioList.add(new Usuario(5, "Lara"));

    //Conversão da lista para Map
    Map<Integer, Usuario> conversaoMap = usuarioList.stream()
            .collect(Collectors.toMap(
                    Usuario::getId,
                    u -> u
            ));

    //Saída de dados
    conversaoMap.forEach((i, u) -> {
        System.out.println("ID: " + i + " | Nome: " + u);
    });
}
