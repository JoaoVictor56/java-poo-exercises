package Ex08;

public class Usuario {
    //Declaração de atributos
    private int id;
    private String nome;

    //Construtor
    public Usuario(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    //Getter
    public int getId() {
        return id;
    }

    //Metodo toString
    @Override
    public String toString() {
        return nome;
    }

}
