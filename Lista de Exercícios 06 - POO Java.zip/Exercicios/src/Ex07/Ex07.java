import Ex07.Pessoa;

void main() {
    //Lista principal
    List<Pessoa> pessoaList = new ArrayList<>();

    //Adicionando elementos à lista
    pessoaList.add(new Pessoa("João"));
    pessoaList.add(new Pessoa("Maria"));
    pessoaList.add(new Pessoa("Pedro"));
    pessoaList.add(new Pessoa("Mario"));
    pessoaList.add(new Pessoa("Matusalém"));

    //Concatenação dos nomes
    String stringFinal = pessoaList.stream()
            .map(Pessoa::getNome)
            .collect(Collectors.joining(", "));

    //Saída de dados
    System.out.println(stringFinal);
}
