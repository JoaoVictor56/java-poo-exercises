package Ex07;

public class Pessoa {
    //Declaração de atributos
    private String nome;

    //Construtor
    public Pessoa(String nome) {
        this.nome = nome;
    }

    //Getter
    public String getNome() {
        return nome;
    }

}
