import Ex27.Acesso;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

void main() {
        List<Acesso> acessos = List.of(
            new Acesso("Ana",    LocalDate.of(2024, 1, 10)),
            new Acesso("Bruno",  LocalDate.of(2024, 3, 5)),
            new Acesso("Ana",    LocalDate.of(2024, 4, 22)),
            new Acesso("Carlos", LocalDate.of(2024, 2, 14)),
            new Acesso("Bruno",  LocalDate.of(2024, 5, 1)),
            new Acesso("Ana",    LocalDate.of(2024, 6, 30)),
            new Acesso("Carlos", LocalDate.of(2024, 1, 3))
        );

        Map<String, Optional<LocalDate>> ultimoAcesso = acessos.stream()
            .collect(Collectors.groupingBy(
                Acesso::getUsuario,
                Collectors.mapping(
                    Acesso::getData,
                    Collectors.maxBy(Comparator.naturalOrder())
                )
            ));

        System.out.println("=== Último acesso por usuário ===\n");

        ultimoAcesso.forEach((usuario, optData) ->
            optData.ifPresentOrElse(
                data -> System.out.printf("%-10s → %s%n", usuario, data),
                ()   -> System.out.printf("%-10s → sem registros%n", usuario)
            )
        );

        System.out.println("\n=== Buscando usuário específico ===\n");

        String busca = "Bruno";

        Optional<LocalDate> dataBruno = ultimoAcesso.getOrDefault(
            busca, Optional.empty()
        );

        String resultado = dataBruno
            .map(d -> "Último acesso: " + d)
            .orElse("Usuário não encontrado");

        System.out.println(busca + " → " + resultado);

        String inexistente = "Zelda";

        String semRegistro = Optional.ofNullable(ultimoAcesso.get(inexistente))
            .flatMap(opt -> opt)
            .map(d -> "Último acesso: " + d)
            .orElse("Usuário não encontrado");

        System.out.println(inexistente + " → " + semRegistro);
}
