import Ex28.Arquivo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

void main() {
        List<Arquivo> arquivos = Arrays.asList(
            new Arquivo("foto1.jpg", 500),
            new Arquivo("foto2.jpg", 800),
            new Arquivo("foto3.jpg", 200),
            new Arquivo("foto4.jpg", 1200),
            new Arquivo("aula.pdf", 3000),
            new Arquivo("trabalho.pdf", 4500),
            new Arquivo("relatorio.pdf", 1500),
            new Arquivo("guia.pdf", 5000),
            new Arquivo("musica.mp3", 7000)
        );

        Map<String, List<Arquivo>> top3PorExtensao = arquivos.stream()
            .collect(Collectors.groupingBy(
                Arquivo::getExtensao,
                Collectors.collectingAndThen(
                    Collectors.toList(),
                    list -> list.stream()
                                .sorted(Comparator.comparingLong(Arquivo::getTamanho).reversed())
                                .limit(3)
                                .collect(Collectors.toList())
                )
            ));

        top3PorExtensao.forEach((ext, lista) -> {
            System.out.println("Extensão: ." + ext);
            lista.forEach(arq -> System.out.println("  - " + arq));
        });
}