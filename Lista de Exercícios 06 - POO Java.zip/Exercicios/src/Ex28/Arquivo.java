package Ex28;

public class Arquivo {
    private String nome;
    private long tamanho;

    public Arquivo(String nome, long tamanho) {
        this.nome = nome;
        this.tamanho = tamanho;
    }

    public String getNome() { return nome; }
    public long getTamanho() { return tamanho; }
    public String getExtensao() {
        int index = nome.lastIndexOf('.');
        return (index == -1) ? "sem_extensao" : nome.substring(index + 1);
    }

    @Override
    public String toString() {
        return String.format("%s (%d KB)", nome, tamanho);
    }
}