import Ex29.Vetor;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

void main() {
        List<Vetor> vetores = Arrays.asList(
            new Vetor(10, 5),
            new Vetor(2, 3),
            new Vetor(5, 2),
            new Vetor(3, 10)
        );

        Optional<Vetor> vetorSoma = vetores.stream()
                .reduce((v1, v2) -> new Vetor(v1.getX() + v2.getX(), v1.getY() + v2.getY()));

        vetorSoma.ifPresent(resultado -> 
            System.out.println("O vetor resultante da soma é: " + resultado)
        );
        double somaX = vetores.stream().mapToDouble(Vetor::getX).sum();
        System.out.println("Soma total de X: " + somaX);
}
