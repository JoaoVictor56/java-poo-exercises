package Ex29;

public class Vetor {
    private double x;
    private double y;

    public Vetor(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() { return x; }
    public double getY() { return y; }

    @Override
    public String toString() {
        return String.format("(x: %.1f, y: %.1f)", x, y);
    }
}
