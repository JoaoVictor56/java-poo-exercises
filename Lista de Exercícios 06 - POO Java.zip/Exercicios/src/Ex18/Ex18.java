import Ex18.Item;

void main() {
    List<Item> itemList = new ArrayList<>();

    itemList.add(new Item("Computador", 5));
    itemList.add(new Item("Mouse", 38));
    itemList.add(new Item("Monitor", 20));
    itemList.add(new Item("Teclado", 56));
    itemList.add(new Item("Mousepad", 72));

    String lista = itemList.stream()
            .map(item -> item.getNome() + " (Quantidade: " + item.getQuantidade() + ")")
            .collect(Collectors.joining(" | "));

    System.out.println(lista);
}
