import Ex01.Livro;

void main() {
    //Lista principal
    List<Livro> livroList = new ArrayList<>();

    //Adicionando elementos à lista
    livroList.add(new Livro("Aditya Y. Bhargava", "Entendendo Algoritimos"));
    livroList.add(new Livro("Robert Cecil Martin", "Código Limpo"));
    livroList.add(new Livro("Andy Hunt e Dave Thomas", "O Programador Pragmático"));

    //Lista que contém apenas os títulos
    List<String> livro = livroList.stream()
            .map(Livro::getTitulo)
            .toList();

    //Saída de dados
    IO.println();
    livro.forEach(System.out::println);
}
