package Ex01;

public class Livro {
    //Declaração de atributos
    private String autor;
    private String titulo;

    //Construtor
    public Livro(String autor, String titulo) {
        this.autor = autor;
        this.titulo = titulo;
    }

    //Getter
    public String getTitulo() {
        return titulo;
    }
}
