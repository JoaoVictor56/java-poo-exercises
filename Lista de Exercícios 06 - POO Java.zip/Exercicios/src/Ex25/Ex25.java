import Ex25.Compra;
import Ex25.Item;

import java.util.*;
import java.util.stream.Collectors;

void main() {
        List<Compra> compras = Arrays.asList(
            new Compra(1, Arrays.asList(new Item("Monitor"), new Item("Teclado"))),
            new Compra(2, Arrays.asList(new Item("Mouse"), new Item("Monitor"))),
            new Compra(3, Arrays.asList(new Item("Teclado"), new Item("Cadeira Gamming")))
        );

        Map<String, List<Item>> itensAgrupados = compras.stream()
            .flatMap(compra -> compra.getItens().stream()) 
            .collect(Collectors.groupingBy(Item::getNome));

        itensAgrupados.forEach((nome, lista) -> {
            System.out.println("Item: " + nome + " | Ocorrências: " + lista.size());
        });
}