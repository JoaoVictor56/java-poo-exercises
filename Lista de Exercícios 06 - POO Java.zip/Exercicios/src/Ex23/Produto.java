package Ex23;

public class Produto {
    private int id;
    private String nome;
    private int versao;

    public Produto(int id, String nome, int versao) {
        this.id = id;
        this.nome = nome;
        this.versao = versao;
    }

    public int getId() {
        return id;
    }

    public int getVersao() {
        return versao;
    }

    public String toString() {
        return nome;
    }

}
