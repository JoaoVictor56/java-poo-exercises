import Ex23.Produto;

void main() {
    List<Produto> produtoList = List.of(
            new Produto(1, "Computador", 1),
            new Produto(2, "Mouse", 8),
            new Produto(3, "Monitor", 6),
            new Produto(4, "Teclado", 5),
            new Produto(5, "Headset", 2)
    );

    Map<Integer, Produto> mapa = produtoList.stream()
            .collect(Collectors.toMap(
                    Produto::getId,
                    p -> p,
                    (p1, p2) -> p1.getVersao() > p2.getVersao() ? p1 : p2
            ));

    mapa.forEach((id, produto) -> {
        IO.println("ID: " + id + " | Produto: " +produto + " | Versão: v" + produto.getVersao());
    });
}
