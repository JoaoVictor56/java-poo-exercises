import Ex06.Transacao;

void main() {
    //Lista principal
    List<Transacao> transacaoList = new ArrayList<>();

    //Adicionando elementos à lista
    transacaoList.add(new Transacao(568.67));
    transacaoList.add(new Transacao(150.0));
    transacaoList.add(new Transacao(250.0));
    transacaoList.add(new Transacao(567.0));
    transacaoList.add(new Transacao(869.38));

    //Soma dos valores das transações
    double somaValores = transacaoList.stream()
            .collect(Collectors.summingDouble(Transacao::getValor));

    //Saída de dados
    System.out.println("Soma total das transações: R$" + somaValores);


}
