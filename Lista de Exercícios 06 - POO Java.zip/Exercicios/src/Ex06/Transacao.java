package Ex06;

public class Transacao {
    //Declaração de atributos
    private double valor;

    //Constutor
    public Transacao(double valor) {
        this.valor = valor;
    }

    //Getter
    public double getValor() {
        return valor;
    }

}
