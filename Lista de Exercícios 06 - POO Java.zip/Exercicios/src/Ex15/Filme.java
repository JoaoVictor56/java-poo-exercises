package Ex15;

public class Filme {
    private String nome;
    private String genero;
    private int ano;

    public Filme(String nome, String genero, int ano) {
        this.nome = nome;
        this.genero = genero;
        this.ano = ano;
    }

    public int getAno() {
        return ano;
    }

    public String getGenero() {
        return genero;
    }

    @Override
    public String toString() {
        return nome;
    }
}
