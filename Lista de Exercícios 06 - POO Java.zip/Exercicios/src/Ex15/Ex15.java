import Ex15.Filme;

void main() {
    List<Filme> filmeList = new ArrayList<>();

    filmeList.add(new Filme("Top Gun: Maveick", "Ação", 2022));
    filmeList.add(new Filme("Vingadores: Ultimato", "Ação", 2019));
    filmeList.add(new Filme("Five Nights at Freddy's", "Terror", 2023));
    filmeList.add(new Filme("It, A Coisa", "Terror", 2017));
    filmeList.add(new Filme("Gente Grande", "Comédia", 2010));
    filmeList.add(new Filme("Todo Mundo em Pânico", "Comédia", 2000));

    Map<String, List<Filme>> agrupamentoGenero = filmeList.stream()
            .collect(Collectors.groupingBy(Filme::getGenero));

    Map<Integer, List<Filme>> agrupamentoAno = filmeList.stream()
            .collect(Collectors.groupingBy(Filme::getAno));


    agrupamentoGenero.forEach((s, f) -> {
        System.out.println("Gênero: " + s + " | Ex15.Filme: " + f);
    });

    System.out.println();

    agrupamentoAno.forEach((i, f) -> {
        System.out.println("Ano: " + i + " | Ex15.Filme: " + f);
    });

}
