import Ex02.Venda;

void main() {
    //Lista principal
    List<Venda> vendaList = new ArrayList<>();

    //Adicionando elementos à lista
    vendaList.add(new Venda("15.00"));
    vendaList.add(new Venda("30.00"));
    vendaList.add(new Venda("45.00"));

    //Lista para converter String para double
    List<Double> valores = vendaList.stream()
            .map(v -> Double.parseDouble(v.getValor()))
            .toList();

    //Imprime os resultados
    valores.forEach(v -> {
        System.out.println("R$" + v);
    });
}
