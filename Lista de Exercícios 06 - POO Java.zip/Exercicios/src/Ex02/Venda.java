package Ex02;

public class Venda {
    //Declaração de atributos
    private String valor;

    //Cinstrutor
    public Venda(String venda) {
        this.valor = venda;
    }

    //Getter
    public String getValor() {
        return valor;
    }
}
