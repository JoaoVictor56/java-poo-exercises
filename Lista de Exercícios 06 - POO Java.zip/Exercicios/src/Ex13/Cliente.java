package Ex13;

public class Cliente {
    private String nome;
    private boolean ativo;

    public Cliente(String nome, boolean ativo) {
        this.nome = nome;
        this.ativo = ativo;
    }

    public boolean isAtivo() {
        return ativo;
    }

    @Override
    public String toString() {
        return nome;
    }
}
