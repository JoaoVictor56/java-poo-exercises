import Ex13.Cliente;

void main() {
    List<Cliente> clienteList = new ArrayList<>();

    clienteList.add(new Cliente("João", true));
    clienteList.add(new Cliente("Maria", true));
    clienteList.add(new Cliente("Pedro", false));
    clienteList.add(new Cliente("Ana", false));
    clienteList.add(new Cliente("Mario", true));

    Map<Boolean, List<Cliente>> ativo = clienteList.stream()
            .collect(Collectors.partitioningBy(Cliente::isAtivo));

    ativo.forEach((b, c) -> {
        System.out.println("Ex13.Cliente: " + c + " | Ativo: " + b);
    });
}
