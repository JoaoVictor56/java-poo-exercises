import Ex10.Carro;

void main() {
    //Lista principal
    List<Carro> carroList = new ArrayList<>();

    //Adicionando elementos à lista
    carroList.add(new Carro("Ford Fusion", 2006));
    carroList.add(new Carro("Fiat Uno", 2008));
    carroList.add(new Carro("Chevrolet Onix", 2020));
    carroList.add(new Carro("BMW M3", 2026));

    //Lista apenas com os anos de fabricação
    List<Integer> anosFabricacao = carroList.stream()
            .map(Carro::getAno)
            .toList();

    //Saída de dados
    anosFabricacao.forEach(System.out::println);
}
