package Ex10;

public class Carro {
    //Declaração de atributos
    private String modelo;
    private int ano;

    //Construtor
    public Carro(String modelo, int ano) {
        this.modelo = modelo;
        this.ano = ano;
    }

    //Getter
    public int getAno() {
        return ano;
    }

}
