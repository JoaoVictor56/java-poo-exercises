package Ex11;

public class Pedido {
    //Declaração de atributos
    private int id;
    private double valor;

    //Construtor
    public Pedido(int id, double valor) {
        this.id = id;
        this.valor = valor;
    }

    //Getter (id)
    public int getId() {
        return id;
    }

    //Getter (valor)
    public double getValor() {
        return valor;
    }
}
