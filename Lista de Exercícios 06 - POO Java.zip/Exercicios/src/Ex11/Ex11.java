import Ex11.Pedido;

void main() {
    //Lista principal
    List<Pedido> pedidoList = new ArrayList<>();

    //Adicionando elementos à lista
    pedidoList.add(new Pedido(1, 124.63));
    pedidoList.add(new Pedido(2, 163));
    pedidoList.add(new Pedido(3, 863.68));
    pedidoList.add(new Pedido(2, 1503.54));
    pedidoList.add(new Pedido(1, 366.32));
    pedidoList.add(new Pedido(3, 366.32));

    //Agrupamento por ID e soma dos pedidos
    Map<Integer, Double> somaValores = pedidoList.stream()
            .collect(Collectors.groupingBy(
                    Pedido::getId,
                    Collectors.summingDouble(Pedido::getValor)
            ));

    //Saída de dados
    somaValores.forEach((i, d) -> {
        System.out.println("ID: " + i + " | Valor somado: R$" + d);
    });
}