import Ex14.Estudante;

void main() {
    List<Estudante> estudanteList = new ArrayList<>();

    estudanteList.add(new Estudante("João", 9.0));
    estudanteList.add(new Estudante("Maria", 10.0));
    estudanteList.add(new Estudante("Pedro", 8.6));
    estudanteList.add(new Estudante("Ana", 4.8));
    estudanteList.add(new Estudante("Francisco", 2.5));

    Double media = estudanteList.stream()
            .collect(Collectors.averagingDouble(Estudante::getNota));

    System.out.format("Média da sala: %.2f", media);
}
