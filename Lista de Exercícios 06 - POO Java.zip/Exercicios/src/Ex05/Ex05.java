import Ex05.Funcionario;

void main() {
    List<Funcionario> funcionarioList = new ArrayList<>();

    funcionarioList.add(new Funcionario("João", "TI"));
    funcionarioList.add(new Funcionario("Maria", "TI"));
    funcionarioList.add(new Funcionario("Pedro", "RH"));
    funcionarioList.add(new Funcionario("Ana", "RH"));
    funcionarioList.add(new Funcionario("Fabricio", "ADM"));

    Map<String, Long> agrupamento = funcionarioList.stream()
            .collect(Collectors.groupingBy(
                    Funcionario::getDepartamento,
                    Collectors.counting()
            ));

    agrupamento.forEach((s, f) -> {
        System.out.println("Departamento: " + s + " | Qtd. Funcionarios: " + f);
    });
}