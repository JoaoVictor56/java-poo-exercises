import Ex09.Tarefa;

void main() {
    //Lista principal
    List<Tarefa> tarefaList = new ArrayList<>();

    //Adicionando elementos à lista
    tarefaList.add(new Tarefa("Estudar", true));
    tarefaList.add(new Tarefa("Fazer o almoço", true));
    tarefaList.add(new Tarefa("Treinar", true));
    tarefaList.add(new Tarefa("Lipar a casa", false));
    tarefaList.add(new Tarefa("Fazer a janta", false));

    //Lista de tarefas concluídas
    List<String> filtro = tarefaList.stream()
            .filter(tarefa -> tarefa.isConcluida() == true)
            .map(Tarefa::getTitulo)
            .toList();

    //Saída de dados
    tarefaList.forEach(System.out::println);

}
