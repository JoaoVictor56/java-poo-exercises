package Ex09;

public class Tarefa {
    //Declaração de atributos
    private String titulo;
    private boolean concluida;

    //Construtor
    public Tarefa(String titulo, boolean concluida) {
        this.titulo = titulo;
        this.concluida = concluida;
    }

    //Getter (título)
    public String getTitulo() {
        return titulo;
    }

    //Getter (concluida)
    public boolean isConcluida() {
        return concluida;
    }

}
