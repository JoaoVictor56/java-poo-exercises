import Ex04.Item;

void main() {
    //Lista principal
    List<Item> itemList = new ArrayList<>();

    //Adicionando elementos à lista
    itemList.add(new Item("Computador", "Eletronico"));
    itemList.add(new Item("Camiseta Azul", "Vestuário"));
    itemList.add(new Item("Calça Jeans Azul", "Vestuário"));
    itemList.add(new Item("Monitor Bluecase", "Eletronico"));
    itemList.add(new Item("Camisa social branca", "Vestuário"));
    itemList.add(new Item("Teclado Red Switch", "Eletronico"));

    //Lista de agrupamento
    Map<String, List<Item>> agrupamento = itemList.stream()
            .collect(Collectors.groupingBy(Item::getCategoria));

    agrupamento.forEach((categoria, lista) -> {
        System.out.println(categoria);
        System.out.println(lista);
    });
}
