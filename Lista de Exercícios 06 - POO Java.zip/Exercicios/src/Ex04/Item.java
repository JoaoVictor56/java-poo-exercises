package Ex04;

public class Item {
    //Declaração de Atributos
    private String nome;
    private String categoria;

    //Construtor
    public Item(String nome, String categoria) {
        this.nome = nome;
        this.categoria = categoria;
    }

    //Getter categoria
    public String getCategoria() {
        return categoria;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + " | Categoria: " + categoria;
    }
}
