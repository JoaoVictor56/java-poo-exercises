package Ex30;

public class Funcionario {
    private String nome;
    private Departamento depto;

    public Funcionario(String nome, Departamento depto) {
        this.nome = nome;
        this.depto = depto;
    }

    public String getNome() { return nome; }
    public Departamento getDepto() { return depto; }

    @Override
    public String toString() { return nome; }
}
