import Ex30.Departamento;
import Ex30.Funcionario;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

void main() {
        Departamento TI = new Departamento("TI");
        Departamento RH = new Departamento("RH");
        Departamento Vendas = new Departamento("Vendas");

        List<Departamento> departamentos = Arrays.asList(TI, RH, Vendas);

        List<Funcionario> funcionarios = Arrays.asList(
            new Funcionario("Alice", TI),
            new Funcionario("Bob", TI),
            new Funcionario("Carol", RH),
            new Funcionario("David", Vendas),
            new Funcionario("Eve", RH)
        );

        Map<Departamento, List<Funcionario>> funcionariosPorDepto = funcionarios.stream()
            .collect(Collectors.groupingBy(Funcionario::getDepto));

        funcionariosPorDepto.forEach((depto, lista) -> {
            System.out.println(depto.getNome() + " -> " + lista);
        });

        System.out.println("\n--- Garantindo todos os departamentos ---");
        Map<Departamento, List<Funcionario>> mapaCompleto = departamentos.stream()
            .collect(Collectors.toMap(
                depto -> depto,
                depto -> funcionarios.stream()
                            .filter(f -> f.getDepto().equals(depto))
                            .collect(Collectors.toList())
            ));

        mapaCompleto.forEach((d, l) -> System.out.println(d.getNome() + ": " + l.size() + " funcionários"));
}
