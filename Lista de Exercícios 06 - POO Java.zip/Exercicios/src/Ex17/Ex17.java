import Ex17.Venda;

void main() {
  List<Venda> vendaList = new ArrayList<>();

  vendaList.add(new Venda("Computador Pichau Gamer", 2163.64));
  vendaList.add(new Venda("Monitor Bluecase ", 650.9));
  vendaList.add(new Venda("Teclado Gamer TGT", 153.36));
  vendaList.add(new Venda("Mouse Gamer Razer", 247.33));

  Map<String, List<Venda>> agrupamento = vendaList.stream()
          .collect(Collectors.groupingBy(Venda::getProduto));

  DoubleSummaryStatistics media = vendaList.stream()
          .collect(Collectors.summarizingDouble(Venda::getValor));

  agrupamento.forEach((a, b) -> {
    IO.println(a);
  });

}
