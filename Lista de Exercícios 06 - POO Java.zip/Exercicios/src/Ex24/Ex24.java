import Ex24.Palavra;

import java.util.*;
import java.util.stream.Collectors;

void main() {
        List<Palavra> listapalavras = Arrays.asList(
            new Palavra("banana"),
            new Palavra("abacaxi"),
            new Palavra("abacaxi"),
            new Palavra("laranja"),
            new Palavra("abacaxi"),
            new Palavra("banana")
        );  


        Map<String, Long> frequencia = listapalavras.stream()
            .map(Palavra::getTexto)
            .collect(Collectors.groupingBy(
                palavra -> palavra,
                Collectors.counting()
            ));

        System.out.println("Frequência das palavras:");
        frequencia.forEach((palavra, contagem) -> System.out.println(palavra + ": " + contagem)
        );
}
