import Ex26.Funcionario;

import java.util.*;
import java.util.stream.Collectors;

void main() {
        List<Funcionario> funcionarios = List.of(
            new Funcionario("Ana",     8500.00),
            new Funcionario("Bruno",   3200.00),
            new Funcionario("Carla",  12000.00),
            new Funcionario("Daniel",  4800.00),
            new Funcionario("Elena",   7300.00),
            new Funcionario("Felipe",  2900.00),
            new Funcionario("Gabi",    9100.00)
        );
        
        double media = funcionarios.stream()
            .mapToDouble(Funcionario::getSalario)
            .average()
            .orElse(0.0);

        System.out.printf("Média salarial: R$ %.2f%n%n", media);

        Map<Boolean, List<Funcionario>> particionados = funcionarios.stream()
            .collect(Collectors.partitioningBy(
                f -> f.getSalario() > media
            ));

        System.out.println("=== Acima da média ===");
        particionados.get(true).stream()
            .map(Funcionario::toString)
            .forEach(System.out::println);

        System.out.println("\n=== Abaixo ou igual à média ===");
        particionados.get(false).stream()
            .map(Funcionario::toString)
            .forEach(System.out::println);
}
