import Ex19.Atleta;

void main() {
    List<Atleta> atletaList = new ArrayList<>();

    atletaList.add(new Atleta("João", 85));
    atletaList.add(new Atleta("Maria", 100));
    atletaList.add(new Atleta("Francisco", 35));
    atletaList.add(new Atleta("Rayssa", 70));

    List<Atleta> decrescente = atletaList.stream()
            .sorted(Comparator.comparing(Atleta::getPontuacao).reversed())
            .toList();

    decrescente.forEach(System.out::println);
}
