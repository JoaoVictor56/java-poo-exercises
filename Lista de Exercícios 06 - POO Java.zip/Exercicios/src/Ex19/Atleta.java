package Ex19;

public class Atleta {
    private String nome;
    private int pontuacao;

    public Atleta(String nome, int pontos) {
        this.nome = nome;
        this.pontuacao = pontos;
    }

    public int getPontuacao() {
        return pontuacao;
    }

    @Override
    public String toString() {
        return "Ex19.Atleta: " + nome + " (" + pontuacao + "pts)";
    }
}
