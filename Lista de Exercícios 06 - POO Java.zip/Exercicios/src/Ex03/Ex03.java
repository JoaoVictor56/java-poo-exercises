import Ex03.Produto;

void main() {
    //Lista principal
    List<Produto> produtoList = new ArrayList<>();

    //Adicionando elementos à lista
    produtoList.add(new Produto("Computador Pichau Gamer", 13000));
    produtoList.add(new Produto("Monitor Bluecase", 529));
    produtoList.add(new Produto("Mousepad", 59.99));
    produtoList.add(new Produto("Teclado TGT Blue Switch", 136));
    produtoList.add(new Produto("Mouse Knup", 35));

    //Lista de formatação
    List<String> formatado = produtoList.stream()
            .filter(produto -> produto.getPreco() > 100)
            .map(p -> p.getNome() + " | R$" + p.getPreco())
            .toList();

    //Mostra os resultados
    formatado.forEach(System.out::println);
}
