package Ex03;

public class Produto {
    //Declaração de atributos
    private String nome;
    private double preco;

    //Construtor
    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    //Getter (nome)
    public String getNome() {
        return nome;
    }

    //Getter (preço)
    public double getPreco() {
        return preco;
    }

}
