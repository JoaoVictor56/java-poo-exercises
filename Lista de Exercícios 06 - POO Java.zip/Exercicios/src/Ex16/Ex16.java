import Ex16.Tarefa;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

void main() {

    List<Tarefa> tarefas = Arrays.asList(
            new Tarefa(101, 1, "Configurar Banco de Dados"),
            new Tarefa(102, 1, "Criar Entidades"),
            new Tarefa(201, 2, "Desenhar Protótipo"),
            new Tarefa(202, 2, "Validar com Cliente"),
            new Tarefa(103, 1, "Configurar Spring Security")
    );


    Map<Integer, Map<Integer, String>> submapaProjetos = tarefas.stream()
            .collect(Collectors.groupingBy(
                    Tarefa::getProjetoId,
                    Collectors.toMap(
                            Tarefa::getId,
                            Tarefa::getDescricao
                    )
            ));

    submapaProjetos.forEach((projId, tarefasMapa) -> {
        System.out.println("Projeto ID: " + projId);
        tarefasMapa.forEach((tId, desc) -> {
            System.out.println("   [Tarefa " + tId + "]: " + desc);
        });
    });
}

