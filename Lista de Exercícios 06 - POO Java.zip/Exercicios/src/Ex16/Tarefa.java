package Ex16;

public class Tarefa {
    private int id;
    private int projetoId;
    private String descricao;

    public Tarefa(int id, int projetoId, String descricao) {
        this.id = id;
        this.projetoId = projetoId;
        this.descricao = descricao;
    }

    public int getId() {
        return id;
    }

    public int getProjetoId() {
        return projetoId;
    }

    public String getDescricao() { 
        return descricao; 
    }
}
