import Ex21.Transacao;

void main() {
    List<Transacao> transacaoList = new ArrayList<>();

    transacaoList.add(new Transacao("Depósito", 162.0));
    transacaoList.add(new Transacao("Depósito", 250.0));
    transacaoList.add(new Transacao("Depósito", 682.0));
    transacaoList.add(new Transacao("Saque", 50.0));
    transacaoList.add(new Transacao("Saque", 20.0));
    transacaoList.add(new Transacao("Saque", 69.0));
    transacaoList.add(new Transacao("Empréstimo", 15000.0));
    transacaoList.add(new Transacao("Empréstimo", 20000.0));

    Map<String, Optional<Transacao>> lista = transacaoList.stream()
            .collect(Collectors.groupingBy(Transacao::getDescricao,
                    Collectors.reducing((t1, t2) ->
                            t1.getValor() > t2.getValor() ? t1 : t2
                    )));

    lista.forEach((b, tran) -> {
        tran.ifPresent(t ->
                System.out.println("Descrição: " + b + " | Maior valor: R$" + t.getValor())
        );
    });
}
