public class Dispositivo {

    public void conectarInternet() {
        System.out.println("Conectando o dispositivo à internet...");
    }
}
