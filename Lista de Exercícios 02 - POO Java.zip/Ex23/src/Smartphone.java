public class Smartphone extends Dispositivo {
    @Override
    public void conectarInternet() {
        System.out.println("Conectando o Smartphone à internet...");
    }
}
