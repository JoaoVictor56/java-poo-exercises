public class Main {
    public static void main(String[] args) {
        Smartphone celular = new Smartphone();
        SmartTV tv = new SmartTV();

        System.out.println();

        celular.conectarInternet();
        tv.conectarInternet();

    }
}