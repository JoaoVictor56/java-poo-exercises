public class SmartTV extends Dispositivo {
    @Override
    public void conectarInternet() {
        System.out.println("Conectando SmartTV à internet");
    }
}
