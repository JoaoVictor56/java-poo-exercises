public class Main {
    public static void main(String[] args) {
        Eletronico eletronico = new Eletronico(1500, 35);
        Alimento alimento = new Alimento(1200, 25);

        System.out.println();

        eletronico.calcularDesconto();
        System.out.println();
        alimento.calcularDesconto();

    }
}