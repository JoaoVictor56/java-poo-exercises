public abstract class Produto {
    private double preco;
    private double desconto;

    public Produto(double preco, double desconto) {
        this.preco = preco;
        this.desconto = desconto;
    }

    public double getPreco() {
        return preco;
    }

    public double getDesconto() {
        return desconto;
    }

    public abstract void calcularDesconto();

}
