public class Alimento extends Produto {
    public Alimento(double preco, double desconto) {
        super(preco, desconto);
    }

    @Override
    public void calcularDesconto() {
        double resultDesconto = getPreco() * (getDesconto() / 100);

        System.out.format("Valor inicial.....: R$%.2f\n", getPreco());
        System.out.format("Valor do desconto.: R$%.2f\n", resultDesconto);
        System.out.format("Valor com desconto: R$%.2f\n", getPreco() - resultDesconto);
    }
}
