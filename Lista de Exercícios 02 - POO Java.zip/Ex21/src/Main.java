public class Main {
    public static void main(String[] args) {
        Facebook face = new Facebook();
        Twitter x = new Twitter();

        System.out.println();

        face.postar();
        face.curtir();

        System.out.println();

        x.postar();
        x.curtir();
    }
}