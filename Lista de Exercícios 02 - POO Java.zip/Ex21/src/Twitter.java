public class Twitter extends RedeSocial {
    @Override
    public void postar() {
        System.out.println("Postando uma publicação no Twitter...");
    }

    @Override
    public void curtir() {
        System.out.println("Curtindo uma publicação no Twitter...");
    }
}
