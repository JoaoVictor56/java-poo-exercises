public class RedeSocial {

    public void postar() {
        System.out.println("Publicação postada");
    }

    public void curtir() {
        System.out.println("Publicação curtida");
    }

}
