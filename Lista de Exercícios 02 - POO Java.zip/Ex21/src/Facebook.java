public class Facebook extends RedeSocial {

    @Override
    public void postar() {
        System.out.println("Postando uma publicação no Facebook...");
    }

    public void curtir() {
        System.out.println("Curtindo uma publicação no Facebook...");
    }
}
