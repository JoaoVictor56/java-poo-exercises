public class Pizza extends Prato {

    @Override
    public void prato() {
        System.out.println("A pizza está sendo preparada");
    }
}
