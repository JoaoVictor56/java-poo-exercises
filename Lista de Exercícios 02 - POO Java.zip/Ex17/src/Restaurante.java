public class Restaurante {

}
