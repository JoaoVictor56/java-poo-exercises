public class Main {
    public static void main(String[] args) {
        Prato prato = new Prato();
        Pizza pizza = new Pizza();
        Sushi sushi = new Sushi();

        System.out.println();

        prato.prato();
        pizza.prato();
        sushi.prato();

    }
}