public class Sushi extends Prato {

    @Override
    public void prato() {
        System.out.println("O sushi está sendo preparado");
    }
}
