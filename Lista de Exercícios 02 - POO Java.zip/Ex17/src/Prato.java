public class Prato extends Restaurante {

    public void prato() {
        System.out.println("O prato está sendo preparado");
    }
}
