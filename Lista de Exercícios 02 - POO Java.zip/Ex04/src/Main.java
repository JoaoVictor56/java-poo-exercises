import Exercicio13.Empresa;
import Exercicios04_07_12.Estagiario;
import Exercicios04_07_12.Gerente;

public class Main {
    public static void main(String[] args) {
        Empresa empresa = new Empresa();

        Gerente gerente = new Gerente(5000);
        Estagiario estagiario = new Estagiario(1500);

        //=========|Ex04|=========
        gerente.calcularSalario();
        estagiario.calcularSalario();

        System.out.println("\n");

        //=========|Ex07|=========
        gerente.descansar();
        estagiario.descansar();

        //=========|Ex12|=========
        System.out.print("\n");
        gerente.calcularBonificacao();

        //=========|Ex13|=========
        empresa.adicionarFuncionarios(gerente);
        empresa.adicionarFuncionarios(gerente);
        empresa.adicionarFuncionarios(estagiario);
        empresa.adicionarFuncionarios(estagiario);
        empresa.adicionarFuncionarios(estagiario);
        empresa.adicionarFuncionarios(estagiario);
        System.out.print("\n");
        empresa.listarFuncionarios();
    }
}