package Exercicio13;

import Exercicios04_07_12.Funcionario;
import java.util.ArrayList;
import java.util.List;

public class Empresa {
    private List<Funcionario> funcionarios = new ArrayList<>();

    //Metodo para inserir funcionarios na lista
    public void adicionarFuncionarios(Funcionario func) {
        this.funcionarios.add(func);
    }

    //Metodo para mostrar a lista de funcionarios
    public void listarFuncionarios() {
        System.out.println("=-=-=|Lista de funcionários|=-=-=");
        for (Funcionario f : funcionarios) {
            f.calcularSalario();

            f.calcularBonificacao();

            System.out.println("--------------------------------");
        }
    }

}
