package Exercicios04_07_12;

public class Estagiario extends Funcionario {
    //=========|Ex04|=========

    //Construtor
    public Estagiario(float salario) {
        super(salario);
    }

    //Sobrescrita do metodo para exibir o salário
    @Override
    public void calcularSalario() {
        System.out.format("Salario estagiário: R$%.2f\n", getSalario());
    }

}