package Exercicios04_07_12;

public class Gerente extends Funcionario {
    //=========|Ex04|=========

    //Construtor
    public Gerente(float salario) {
        super(salario);
    }

    //Sobrescrita do metodo para exibir o salário
    @Override
    public void calcularSalario() {
        System.out.format("Salario gerente...: R$%.2f\n", getSalario());
    }

    //=========|Ex12|=========

    //Sobrescrita do metodo para calcular a bonificação
    @Override
    public void calcularBonificacao() {
        double bonus = 500;
        System.out.format("Salario com bonus.: R$%.2f\n", getSalario() + bonus);
    }

}
