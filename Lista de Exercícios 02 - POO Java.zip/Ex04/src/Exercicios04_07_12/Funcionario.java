package Exercicios04_07_12;

public abstract class Funcionario {
    //=========|Ex04|=========

    //Declaração de atributos
    private float salario;

    //Construtor
    public Funcionario(float salario) {
        this.salario = salario;
    }

    //Getter (salario)
    public float getSalario() {
        return salario;
    }

    //Metodo para mostrar o salário do funcionário
    public abstract void calcularSalario();

    //=========|Ex07|=========

    //Metodo descansar
    public void descansar() {
        System.out.println("Descansando....");
    }

    //=========|Ex12|=========

    //Metodo para calcular a bonificação do funcionário (caso ele tenha)
    public void calcularBonificacao() {
        System.out.println("Sem bonificação");
    }

}
