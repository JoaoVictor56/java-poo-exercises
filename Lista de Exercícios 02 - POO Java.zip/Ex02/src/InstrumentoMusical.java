public abstract class InstrumentoMusical {
    //=========|Ex02|=========

    //Metodo abstrato (tocar)
    public abstract void tocar();
}
