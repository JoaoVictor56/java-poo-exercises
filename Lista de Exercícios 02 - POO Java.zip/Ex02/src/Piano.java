public class Piano extends InstrumentoMusical {
    //=========|Ex02|=========

    //Sobrescrição do metodo (tocar)
    @Override
    public void tocar() {
        System.out.println("Som de piano");
    }

}
