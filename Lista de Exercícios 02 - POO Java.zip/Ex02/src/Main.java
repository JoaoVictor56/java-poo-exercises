public class Main {
    public static void main(String[] args) {
        //Criação de Objetos
        Piano piano = new Piano();
        Guitarra guitarra = new Guitarra();

        //=========|Ex02|=========

        //Chama os metodos
        piano.tocar();
        guitarra.tocar();
    }
}