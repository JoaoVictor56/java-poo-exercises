public class Desktop extends Computador {
    @Override
    public void processar() {
        System.out.println("Desktop processando...");
    }
}
