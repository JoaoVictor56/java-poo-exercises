public class Computador {
    public void processar() {

    }
}
