public class Main {
    public static void main(String[] args) {
        Desktop desktop = new Desktop();
        Notebook notebook = new Notebook();

        System.out.println();

        desktop.processar();
        notebook.processar();

    }
}