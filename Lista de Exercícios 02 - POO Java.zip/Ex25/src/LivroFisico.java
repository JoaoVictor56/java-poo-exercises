public class LivroFisico extends Livro {
    @Override
    public void abrir() {
        System.out.println("Abrindo livro físico...");
    }
}
