public class Main {
    public static void main(String[] args) {
        Ebook ebook = new Ebook();
        LivroFisico livroFisico = new LivroFisico();

        System.out.println();

        ebook.abrir();
        livroFisico.abrir();

    }
}