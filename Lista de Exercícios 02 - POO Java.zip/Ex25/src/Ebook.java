public class Ebook extends Livro {
    @Override
    public void abrir() {
        System.out.println("Abrindo Ebook...");
    }
}
