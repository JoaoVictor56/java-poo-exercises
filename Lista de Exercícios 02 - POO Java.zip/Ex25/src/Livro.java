public class Livro {
    public void abrir() {
        System.out.println("Abrindo livro...");
    }
}
