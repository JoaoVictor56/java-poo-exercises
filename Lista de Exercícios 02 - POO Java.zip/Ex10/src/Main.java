import Exercicio10.Guerreiro;
import Exercicio10.Mago;
import Exercicio11.Jogador;

public class Main {
    public static void main(String[] args) {
        Guerreiro guerreiro = new Guerreiro();
        Mago mago = new Mago();
        Jogador player = new Jogador();

        System.out.print("\n");

        //=========|Ex10|=========

        guerreiro.atacar();
        mago.atacar();

        //=========|Ex11|=========
        player.usarHabilidadeEspecial();

    }
}