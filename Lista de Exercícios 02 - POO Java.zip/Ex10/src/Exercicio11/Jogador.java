package Exercicio11;

import Exercicio10.Personagem;

public class Jogador extends Personagem {
    //=========|Ex11|=========
    @Override
    public void atacar() {
        System.out.println("Jogador está com a classe Guerreiro");
    }

    public void usarHabilidadeEspecial() {
        System.out.println("Habilidade especial foi utilizada!");
    }

}