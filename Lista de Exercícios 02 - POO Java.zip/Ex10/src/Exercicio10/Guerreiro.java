package Exercicio10;

public class Guerreiro extends Personagem {
    //=========|Ex10|=========

    //Sobrescrição do metodo atacar (para o guerreiro)
    @Override
    public void atacar() {
        System.out.println("Guerreiro atacou seu inimigo");
    }

}
