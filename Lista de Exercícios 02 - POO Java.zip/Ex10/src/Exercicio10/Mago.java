package Exercicio10;

public class Mago extends Personagem {
    //=========|Ex10|=========

    //Sobrescrição do metodo atacar (para o mago)
    @Override
    public void atacar() {
        System.out.println("Mago atacou seu inimigo");
    }
}
