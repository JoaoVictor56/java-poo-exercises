package Exercicio10;

public abstract class Personagem {
    //=========|Ex10|=========

    //Metodo atacar
    public abstract void atacar();
}
