public class Word extends Documento {
    @Override
    public void imprimir() {
        System.out.println("Imprimindo documento Word");
    }
}
