public class Main {
    public static void main(String[] args) {
        PDF pdf = new PDF();
        Word word = new Word();

        System.out.print("\n");

        pdf.imprimir();
        word.imprimir();

    }
}