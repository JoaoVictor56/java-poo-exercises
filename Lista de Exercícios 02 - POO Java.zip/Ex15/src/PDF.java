public class PDF extends Documento {

    @Override
    public void imprimir() {
        System.out.println("Imprimindo o documento PDF");
    }
}
