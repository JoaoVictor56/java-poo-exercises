public class Main {
    public static void main(String[] args) {
        Engenheiro eng = new Engenheiro();
        Professor prof = new Professor();

        System.out.println();

        eng.executar();
        prof.executar();

    }
}