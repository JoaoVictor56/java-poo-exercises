public class Professor extends Trabalho {
    @Override
    public void executar() {
        System.out.println("Professor está trabalhando...");
    }
}
