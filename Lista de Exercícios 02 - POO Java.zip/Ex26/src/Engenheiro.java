public class Engenheiro extends Trabalho {
    @Override
    public void executar() {
        System.out.println("Engenheiro está trabalhando...");
    }
}
