public class Trabalho {

    public void executar() {
        System.out.println("Trabalhando...");
    }

}
