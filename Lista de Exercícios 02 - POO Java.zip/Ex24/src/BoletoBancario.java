public class BoletoBancario extends Pagamento {
    @Override
    public void realizarPagamento() {
        System.out.println("O boleto bancário está sendo pago...");
    }
}
