public class CartaoCredito extends Pagamento {
    @Override
    public void realizarPagamento() {
        System.out.println("O cartão de crédito está sendo pago...");
    }
}
