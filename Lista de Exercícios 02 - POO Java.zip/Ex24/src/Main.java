public class Main {
    public static void main(String[] args) {
        CartaoCredito cartao = new CartaoCredito();
        BoletoBancario boleto = new BoletoBancario();

        System.out.println();

        cartao.realizarPagamento();
        boleto.realizarPagamento();

    }
}