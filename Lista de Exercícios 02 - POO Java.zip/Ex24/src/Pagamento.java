public class Pagamento {
    public void realizarPagamento() {
        System.out.println("O pagamento sendo efetuado...");
    }
}
