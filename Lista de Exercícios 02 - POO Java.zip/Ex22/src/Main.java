public class Main {
    public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente();
        ContaPoupanca cp = new ContaPoupanca();

        System.out.println();

        cc.depositar();
        cc.sacar();

        System.out.println();
        System.out.println("===================================");
        System.out.println();

        cp.depositar();
        cp.sacar();

    }
}