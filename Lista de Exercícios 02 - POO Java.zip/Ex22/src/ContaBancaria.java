public class ContaBancaria {
    public void sacar() {
        System.out.println("Sacando...");
    }

    public void depositar() {
        System.out.println("Depositando...");
    }

}
