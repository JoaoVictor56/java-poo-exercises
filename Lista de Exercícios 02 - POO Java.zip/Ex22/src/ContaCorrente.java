public class ContaCorrente extends ContaBancaria {

    @Override
    public void sacar() {
        System.out.println("Sacando da conta corrente...");
    }

    @Override
    public void depositar() {
        System.out.println("Depositando na conta corrente...");

    }

}
