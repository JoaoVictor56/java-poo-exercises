public class Aula {
    public void ministrar() {
        System.out.println("Ministrando...");
    }
}
