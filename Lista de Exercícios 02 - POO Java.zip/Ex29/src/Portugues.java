public class Portugues extends Aula {
    @Override
    public void ministrar() {
        System.out.println("Ministrando a matéria português...");
    }

}
