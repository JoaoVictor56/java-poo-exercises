public class Matematica extends Aula {
    @Override
    public void ministrar() {
        System.out.println("Ministrando a matéria matemática...");
    }

}
