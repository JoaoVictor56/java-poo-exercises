public class Main {
    public static void main(String[] args) {
        Matematica mat = new Matematica();
        Portugues port = new Portugues();

        System.out.println();

        mat.ministrar();
        port.ministrar();

    }
}