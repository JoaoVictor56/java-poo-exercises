public abstract class FormaGeometrica {
    //=========|Ex03|=========

    //Metodo abstrato (calcularArea)
    public abstract void calcularArea();

    //Metodo abstrato (calcularPerimetro)
    public abstract void calcularPerimetro();
}
