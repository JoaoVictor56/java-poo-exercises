public class Circulo extends FormaGeometrica {
    //=========|Ex03|=========

    //Declaração de atributos
    private double raio;

    //Construtor
    public Circulo(double raio) {
        this.raio = raio;
    }

    //Sobrescrição do metodo (calcularArea)
    @Override
    public void calcularArea() {
        double result;

        result = Math.PI * Math.pow(raio, 2);

        System.out.format("Área do Circulo..........: %.2f\n", result);
    }

    //Sobrescrição do metodo (calcularPerimetro)
    @Override
    public void calcularPerimetro() {
        double result;

        result = 2 * Math.PI * raio;

        System.out.format("Circunferencia do Circulo: %.2f\n", result);
    }
}
