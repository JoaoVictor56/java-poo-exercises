public class Main {
    public static void main(String[] args) {
        Circulo circulo = new Circulo(10);
        Retangulo retangulo = new Retangulo(20, 15);

        //=========|Ex03|=========

        //Cálculo da área e da circunferencia do circulo
        circulo.calcularArea();
        circulo.calcularPerimetro();

        //Cálculo da área e do perimetro do retangulo
        retangulo.calcularArea();
        retangulo.calcularPerimetro();
    }
}