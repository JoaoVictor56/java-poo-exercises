public class Retangulo extends FormaGeometrica {
    //=========|Ex03|=========

    //Declaração de atributos
    private double base;
    private double altura;

    //Construtor
    public Retangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    //Sobrescrição do metodo (calcularArea)
    @Override
    public void calcularArea() {
        double result;

        result = base * altura;

        System.out.format("Área do Retângulo........: %.2f\n", result);
    }

    //Sobrescrição do metodo (calcularPerimetro)
    @Override
    public void calcularPerimetro() {
        double result;

        result = 2 * (base * altura);

        System.out.format("Perimetro do Retângulo...: %.2f\n", result);
    }

}
