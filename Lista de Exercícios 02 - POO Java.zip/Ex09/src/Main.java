public class Main {
    public static void main(String[] args) {
        Deposito deposito = new Deposito(1800, 500);
        Sacar saque = new Sacar(1800, 1500);

        //=========|Ex09|=========

        System.out.println("\n");

        //---------Depósito---------
        deposito.realizarTransacao();

        //System.out.println("\n");
        System.out.println("=============================");

        //---------Saque---------
        saque.realizarTransacao();
    }
}