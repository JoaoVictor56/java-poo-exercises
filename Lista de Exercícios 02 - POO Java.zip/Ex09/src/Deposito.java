public class Deposito extends Banco {
    //=========|Ex09|=========

    //Construtor (Subclasse Depósito)
    public Deposito(double saldo, double valor) {
        super(saldo, valor);
    }

    //Sobrescrição do metodo
    @Override
    public void realizarTransacao() {
        if (getValor() <= 0) {
            System.out.println("Insira um valor para realizar o depósito!");
        } else {
            System.out.println("Saldo............: R$" + getSaldo());
            System.out.println("Valor do depósito: R$" + getValor());
            System.out.format("Saldo final......: R$%.2f\n", getSaldo() + getValor());
        }
    }

}
