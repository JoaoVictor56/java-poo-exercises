public abstract class Banco {
    //=========|Ex09|=========
    private double saldo;
    private double valor;

    //Construtor (Classe Banco)
    public Banco(double saldo, double valor) {
        this.saldo = saldo;
        this.valor = valor;
    }

    //Getter (saldo)
    public double getSaldo() {
        return saldo;
    }

    //Getter (valor)
    public double getValor() {
        return valor;
    }

    //Metodo abstrato
    public abstract void realizarTransacao();

}
