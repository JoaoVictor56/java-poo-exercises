public class Sacar extends Banco {
    //=========|Ex09|=========

    //Construtor (Subclasse Sacar)
    public Sacar(double saldo, double valor) {
        super(saldo, valor);
    }

    //Sobrescrição do metodo
    @Override
    public void realizarTransacao() {
        if (getValor() > getSaldo()) {
            System.out.println("Valor insuficiente!");
        } else {
            System.out.println("Saldo.........: R$" + getSaldo());
            System.out.println("Valor do saque: R$" + getValor());
            System.out.format("Saldo final...: R$%.2f\n", getSaldo() + getValor());
        }
    }

}
