public class Main {
    public static void main(String[] args) {
        Cachorro dog = new Cachorro("Bob");
        Gato cat = new Gato("Tom");

        //=========|Ex05|=========
        dog.fazerSom();
        cat.fazerSom();

        //=========|Ex06|=========
        dog.mostrarNome();
        cat.mostrarNome();
    }
}