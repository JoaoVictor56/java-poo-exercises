public abstract class Animal {
    //=========|Ex05|=========

    //Metodo fazerSom (abstrato)
    public abstract void fazerSom();

    //=========|Ex06|=========
    private String nome;

    //Construtor
    public Animal(String nome) {
        this.nome = nome;
    }

    //Getter (nome)
    public String getNome() {
        return nome;
    }
}