public class Gato extends Animal {
    //=========|Ex05|=========

    //Sobrescrita do metodo fazerSom
    @Override
    public void fazerSom() {
        System.out.println("Miau!");
    }

    //=========|Ex06|=========

    //Construtor
    public Gato(String nome) {
        super(nome);
    }

    //Metodo mostrarNome
    public void mostrarNome() {
        System.out.println("Nome do gato....: " + getNome());
    }
}