public class Cachorro extends Animal {
    //=========|Ex05|=========

    //Sobrescrita do metodo fazerSom
    @Override
    public void fazerSom() {
        System.out.println("Au! Au!");
    }

    //=========|Ex06|=========

    //Construtor
    public Cachorro(String nome) {
        super(nome);
    }

    //Metodo mostrarNome
    public void mostrarNome() {
        System.out.println("Nome do cachorro: " + getNome());
    }

}