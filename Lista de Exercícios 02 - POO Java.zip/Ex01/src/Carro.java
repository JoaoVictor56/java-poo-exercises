public class Carro extends Veiculo {
    //=========|Ex01|=========
    @Override
    public void mover() {
        System.out.println("Acelerando");
    }

    //=========|Ex08|=========

    //Construtor (Subclasse Carro)
    public Carro(String cor) {
        super(cor);
    }

    //Sobrescrição do metodo (mostrarCor)
    @Override
    public void mostrarCor() {
        System.out.println("Cor do carro....: " + getCor());
    }

}
