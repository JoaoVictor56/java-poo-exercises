public class Main {
    public static void main(String[] args) {
        Carro carro = new Carro("Cinza");
        Bicicleta bicicleta = new Bicicleta("Verde");

        //=========|Ex01|=========
        carro.mover();
        bicicleta.mover();

        System.out.println("\n");

        //=========|Ex08|=========
        carro.mostrarCor();
        bicicleta.mostrarCor();
    }
}