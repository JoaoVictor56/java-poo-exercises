public class Bicicleta extends Veiculo {
    //=========|Ex01|=========

    //Sobrescrição do metodo mover
    @Override
    public void mover() {
        System.out.println("Pedalando");
    }

    //=========|Ex08|=========

    //Construtor (Subclasse Bicicleta)
    public Bicicleta(String cor) {
        super(cor);
    }

    //Sobrescrição do metodo (mostrarCor)
    @Override
    public void mostrarCor() {
        System.out.println("Cor da bicicleta: " + getCor());
    }
}
