public abstract class Veiculo {
    //=========|Ex01|=========

    //Metodo mover
    public abstract void mover();

    //=========|Ex08|=========

    //Declaração de atributos
    private String cor;

    //Construtor (Classe Veiculo)
    public Veiculo(String cor) {
        this.cor = cor;
    }

    //Metodo para mostrar a cor
    public void mostrarCor() {
        System.out.println("Cor do veículo: " + cor);
    }

    //Getter (cor)
    public String getCor() {
        return cor;
    }

}
