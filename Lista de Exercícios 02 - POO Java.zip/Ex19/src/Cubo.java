public class Cubo extends Forma3D {
    private double lado;

    public Cubo(double lado) {
        this.lado = lado;
    }

    @Override
    public void calcularVolume() {
        System.out.format("Volume do cubo..: %.2f\n", Math.pow(lado, 3));
    }
}
