public class Esfera extends Forma3D {
    private double raio;

    public Esfera(double raio) {
        this.raio = raio;
    }

    @Override
    public void calcularVolume() {
        System.out.format("Volume da esfera: %.2f\n", (4/3) * Math.PI * Math.pow(raio, 3));
    }
}
