public class Forma3D {

    public void calcularVolume() {
        System.out.println();
    }
}
