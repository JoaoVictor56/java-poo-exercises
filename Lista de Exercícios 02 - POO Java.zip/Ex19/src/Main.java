public class Main {
    public static void main(String[] args) {
        Esfera esfera = new Esfera(6);
        Cubo cubo = new Cubo(4);

        esfera.calcularVolume();
        cubo.calcularVolume();

    }
}