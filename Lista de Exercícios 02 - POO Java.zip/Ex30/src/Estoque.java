public class Estoque {
    public void controlarQuantidade() {
        System.out.println("Informações do estoque");
    }
}
