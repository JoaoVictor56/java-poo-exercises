public class Main {
    public static void main(String[] args) {
        Eletronicos eletronicos = new Eletronicos();
        Roupas roupas = new Roupas();

        System.out.println();

        eletronicos.controlarQuantidade();

        System.out.println("\n====================================\n");

        roupas.controlarQuantidade();

    }
}