public class Roupas extends Estoque {

    @Override
    public void controlarQuantidade() {
        System.out.println("Quantidade de Blusas........: 35un");
        System.out.println("Quantidade de Camisetas.....: 70un");
        System.out.println("Quantidade de Calças........: 69un");
        System.out.println("Quantidade de Roupas intimas: 42un");
    }
}
