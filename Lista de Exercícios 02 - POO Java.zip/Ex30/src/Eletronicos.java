public class Eletronicos extends Estoque {

    @Override
    public void controlarQuantidade() {
        System.out.println("Quantidade de Celulares......: 18un");
        System.out.println("Quantidade de Tablets........: 15un");
        System.out.println("Quantidade de Computadores...: 6un");
        System.out.println("Quantidade de Fones de ouvido: 23un");
    }
}
