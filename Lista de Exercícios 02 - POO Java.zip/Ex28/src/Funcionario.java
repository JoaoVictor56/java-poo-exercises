public class Funcionario {

    public void baterPonto() {
        System.out.println("Funcionário bateu o ponto!");
    }
}
