public class Programador extends Funcionario {
    @Override
    public void baterPonto() {
        System.out.println("O programador bateu o ponto!");
    }
}
