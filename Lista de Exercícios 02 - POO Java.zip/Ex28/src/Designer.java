public class Designer extends Funcionario {
    @Override
    public void baterPonto() {
        System.out.println("O Designer bateu o ponto!");
    }
}
