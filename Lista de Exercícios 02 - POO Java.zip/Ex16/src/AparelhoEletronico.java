public abstract class AparelhoEletronico {

    public abstract void ligar();
}
