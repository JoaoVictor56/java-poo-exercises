public class Celular extends AparelhoEletronico {

    @Override
    public void ligar() {
        System.out.println("Ligando o celular....");
    }
}
