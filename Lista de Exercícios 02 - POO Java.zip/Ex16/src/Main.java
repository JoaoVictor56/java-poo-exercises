public class Main {
    public static void main(String[] args) {
        Celular celular = new Celular();
        Tablet tablet = new Tablet();

        System.out.println();

        celular.ligar();
        tablet.ligar();
    }
}