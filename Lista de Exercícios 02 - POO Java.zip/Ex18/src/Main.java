public class Main {
    public static void main(String[] args) {
        JogoCorrida corrida = new JogoCorrida();
        JogoAventura aventura = new JogoAventura();

        System.out.println();

        corrida.iniciar();
        aventura.iniciar();
    }
}