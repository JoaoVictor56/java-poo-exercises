public class JogoAventura extends Jogo {

    @Override
    public void iniciar() {
        System.out.println("Iniciando Jogo de Aventura...");
    }

}
