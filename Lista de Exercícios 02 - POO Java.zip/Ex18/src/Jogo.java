public class Jogo {
    public void iniciar() {
        System.out.println("Iniciando jogo....");
    }
}
