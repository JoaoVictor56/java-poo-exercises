public class JogoCorrida extends Jogo {
    @Override
    public void iniciar() {
        System.out.println("Iniciando Jogo de Corrida...");
    }

}
