public class Moto extends Transporte {
    //=========|Ex14|=========

    @Override
    public void velocidadeMaxima() {
        System.out.println("Velocidade máxima da moto...: 120 Km/h");
    }
}
