public class Main {
    public static void main(String[] args) {
        Caminhao caminhao = new Caminhao();
        Moto moto = new Moto();

        System.out.print("\n");

        caminhao.velocidadeMaxima();
        moto.velocidadeMaxima();

    }
}