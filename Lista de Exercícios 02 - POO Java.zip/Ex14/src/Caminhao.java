public class Caminhao extends Transporte {
    //=========|Ex14|=========

    @Override
    public void velocidadeMaxima() {
        System.out.println("Velocidade máxima do caminão: 100 Km/h");
    }
}
