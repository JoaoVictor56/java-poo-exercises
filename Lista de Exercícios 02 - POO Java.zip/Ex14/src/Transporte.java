public abstract class Transporte {
    //=========|Ex14|=========

    public abstract void velocidadeMaxima();
}
