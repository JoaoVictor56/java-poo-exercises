public class Futebol implements Jogavel {
    @Override
    public void iniciarJogo() {
        System.out.println("Iniciando o futebol...");
    }
}
