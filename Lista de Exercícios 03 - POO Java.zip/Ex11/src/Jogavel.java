public interface Jogavel {
    public void iniciarJogo();
}
