public class Main {
    public static void main(String[] args) {
        Jogavel xadrez = new Xadrez();
        Jogavel futebol = new Futebol();

        System.out.println();

        xadrez.iniciarJogo();
        futebol.iniciarJogo();
    }
}