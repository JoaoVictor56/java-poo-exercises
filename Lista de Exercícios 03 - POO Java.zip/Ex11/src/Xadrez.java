public class Xadrez implements Jogavel {

    @Override
    public void iniciarJogo() {
        System.out.println("Iniciando o xadrez...");
    }
}
