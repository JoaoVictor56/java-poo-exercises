public class Pix implements Pagamento {

    //=========|Ex18|=========
    @Override
    public void pagar() {
        System.out.println("Pagando com pix...");
    }

    @Override
    public void cancelarPagamento() {
        System.out.println("Cancelando pagamento com pix...");
    }
}
