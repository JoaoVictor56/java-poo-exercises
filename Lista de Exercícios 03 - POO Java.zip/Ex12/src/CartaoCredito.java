public class CartaoCredito implements Pagamento {

    //=========|Ex12|=========
    @Override
    public void pagar() {
        System.out.println("Pagando o cartão de crédito...");
    }

    //=========|Ex18|=========
    @Override
    public void cancelarPagamento() {
        System.out.println("Cancelando pagamento do cartão de crédito...");
    }
}
