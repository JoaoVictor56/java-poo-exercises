public class Main {
    public static void main(String[] args) {
        Pagamento cartaoCredito = new CartaoCredito();
        Pagamento boleto = new Boleto();
        Pagamento pix = new Pix();

        System.out.println();

        //=========|Ex12|=========
        cartaoCredito.pagar();
        boleto.pagar();

        System.out.println();

        //=========|Ex18|=========
        pix.cancelarPagamento();
        cartaoCredito.cancelarPagamento();
    }
}