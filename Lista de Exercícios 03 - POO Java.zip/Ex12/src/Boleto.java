public class Boleto implements Pagamento {

    //=========|Ex12|=========
    @Override
    public void pagar() {
        System.out.println("Pagando o boleto...");
    }
}
