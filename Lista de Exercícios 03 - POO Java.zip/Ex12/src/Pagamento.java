public interface Pagamento {
    //=========|Ex12|=========
    public void pagar();

    default void cancelarPagamento() {
        System.out.println("Cancelando pagamento");
    }
}
