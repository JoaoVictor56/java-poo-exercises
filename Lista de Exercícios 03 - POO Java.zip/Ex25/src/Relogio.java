public class Relogio implements Horario {

    public void mostrarHorario() {
        System.out.println("Agora são: " + horas() + ":" + minutos());
    }
}
