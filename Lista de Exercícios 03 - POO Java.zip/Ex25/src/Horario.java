public interface Horario {
    int horas = 12;
    int minutos = 35;

    default int horas() {
        return horas;
    }

    default int minutos() {
        return minutos;
    }
}
