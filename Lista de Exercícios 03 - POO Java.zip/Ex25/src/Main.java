public class Main {
    public static void main(String[] args) {
        Relogio relogio = new Relogio();

        relogio.mostrarHorario();
    }
}