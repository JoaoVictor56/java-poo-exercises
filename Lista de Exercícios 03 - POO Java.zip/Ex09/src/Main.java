public class Main {
    public static void main(String[] args) {
        Imprimivel doc = new Documento();
        Imprimivel img = new Imagem();

        System.out.println();

        //=========|Ex09|=========
        doc.imprimir();
        img.imprimir();

        System.out.println();

        //=========|Ex17|=========
        doc.mostrarMonitor();
    }
}