public interface Imprimivel {

    //=========|Ex09|=========
    public void imprimir();

    default void mostrarMonitor() {
        System.out.println("Mostrar no monitor");
    }
}
