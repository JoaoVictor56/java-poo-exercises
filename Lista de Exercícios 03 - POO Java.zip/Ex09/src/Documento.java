public class Documento implements Imprimivel {

    //=========|Ex09|=========
    @Override
    public void imprimir() {
        System.out.println("Imprimindo documento...");
    }

    //=========|Ex17|=========
    @Override
    public void mostrarMonitor() {
        System.out.println("Exibindo no monitor...");
    }
}
