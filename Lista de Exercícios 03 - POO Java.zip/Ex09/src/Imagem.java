public class Imagem implements Imprimivel {

    //=========|Ex09|=========
    @Override
    public void imprimir() {
        System.out.println("Imprimindo imagem...");
    }
}
