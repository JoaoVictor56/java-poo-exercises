public class Main {
    public static void main(String[] args) {
        InstrumentoMusical violao = new Violao();
        InstrumentoMusical piano = new Piano();

        System.out.println();

        violao.tocar();
        piano.tocar();
    }
}