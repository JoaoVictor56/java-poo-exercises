public interface Banco {
    double taxaJuros = 15;

    public void calcularJuros();

    default double getTaxaJuros() {
        return taxaJuros / 100;
    }
}
