public class Main {
    public static void main(String[] args) {
        Banco cp = new ContaPoupanca(1500);

        System.out.println();

        cp.calcularJuros();

    }
}