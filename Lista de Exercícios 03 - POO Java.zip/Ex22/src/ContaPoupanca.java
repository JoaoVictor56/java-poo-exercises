public class ContaPoupanca implements Banco {
    private double valor;

    public ContaPoupanca(double valor) {
        this.valor = valor;
    }

    @Override
    public void calcularJuros() {
        System.out.format("Valor inicial..: R$%.2f\n", valor);
        System.out.format("Valor com juros: R$%.2f\n", valor * (1 + (getTaxaJuros() / 12)));
        System.out.format("Valor dos juros: R$%.2f\n", valor * (getTaxaJuros() / 12));
    }
}
