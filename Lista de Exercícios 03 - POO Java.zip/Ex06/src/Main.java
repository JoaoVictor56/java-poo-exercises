public class Main {
    public static void main(String[] args) {
        Triatleta triatleta = new Triatleta();

        System.out.println();

        triatleta.corredor();
        triatleta.nadador();
    }
}