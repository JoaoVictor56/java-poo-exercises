public interface Corredor {
    public void corredor();
}
