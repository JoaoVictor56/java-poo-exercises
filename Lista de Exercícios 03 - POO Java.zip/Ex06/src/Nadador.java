public interface Nadador {
    public void nadador();
}
