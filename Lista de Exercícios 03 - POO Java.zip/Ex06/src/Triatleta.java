public class Triatleta implements Nadador, Corredor {
    @Override
    public void nadador() {
        System.out.println("Nadando...");
    }

    @Override
    public void corredor() {
        System.out.println("Correndo...");
    }
}
