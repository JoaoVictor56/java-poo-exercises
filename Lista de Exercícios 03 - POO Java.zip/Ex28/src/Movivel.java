public interface Movivel {
    public void moverParaFrente();

    public void moverParaTras();
}
