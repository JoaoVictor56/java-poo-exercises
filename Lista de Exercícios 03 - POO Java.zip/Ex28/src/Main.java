public class Main {
    public static void main(String[] args) {
        Movivel robo = new Robo();

        System.out.println();

        robo.moverParaFrente();
        robo.moverParaTras();
    }
}