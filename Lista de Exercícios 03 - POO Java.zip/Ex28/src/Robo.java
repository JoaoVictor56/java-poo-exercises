public class Robo implements Movivel {

    @Override
    public void moverParaFrente() {
        System.out.println("O robo está se movendo para frente!");
    }

    @Override
    public void moverParaTras() {
        System.out.println("O robo está se movendo para trás!");
    }
}
