public class RepositorioCliente implements Repositorio {
    @Override
    public void salvar(Object objeto) {
        System.out.println("Salvando cliente " + objeto);
    }

    @Override
    public Object buscar(int id) {
        System.out.println("Buscando Cliente por ID: " + id);
        return null;
    }
}
