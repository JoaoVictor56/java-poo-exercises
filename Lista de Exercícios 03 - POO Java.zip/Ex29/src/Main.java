public class Main {
    public static void main(String[] args) {
        Repositorio repositorio = new RepositorioCliente();

        System.out.println();

        repositorio.salvar("Repositório");
        repositorio.buscar(15);
    }
}