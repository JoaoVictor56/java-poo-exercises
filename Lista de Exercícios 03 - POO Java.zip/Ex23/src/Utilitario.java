public interface Utilitario {
    long calcularFatorial(int n);
}
