public class Main {
    public static void main(String[] args) {
        Utilitario fat = new Matematica();

        System.out.println();

        System.out.println("Fatorial: " + fat.calcularFatorial(5));
    }
}