public class Matematica implements Utilitario {

    @Override
    public long calcularFatorial(int n) {
        long resultado = 1;

        for (int i = 1; i <= n; i++) {
            resultado *= i;
        }

        return resultado;
    }
}