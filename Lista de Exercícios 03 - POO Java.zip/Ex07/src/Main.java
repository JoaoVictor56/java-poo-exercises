public class Main {
    public static void main(String[] args) {
        Banco contaCorrente  = new ContaCorrente(1500, 100);

        System.out.println();

        contaCorrente.depositar();
        contaCorrente.sacar();
        contaCorrente.verSaldo();
    }
}