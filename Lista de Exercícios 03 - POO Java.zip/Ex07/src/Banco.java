public interface Banco {
    public void sacar();
    public void depositar();
    public void verSaldo();
}
