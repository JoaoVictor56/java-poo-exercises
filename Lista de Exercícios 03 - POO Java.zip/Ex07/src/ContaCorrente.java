public class ContaCorrente implements Banco {
    private double saldo;
    private double valor;

    public ContaCorrente(double saldo, double valor) {
        this.saldo = saldo;
        this.valor = valor;
    }

    @Override
    public void sacar() {
        if (valor > saldo) {
            System.out.println("Valor insuficiente!");
        } else {
            saldo = saldo - valor;
            System.out.println("Saldo: R$" + saldo);
        }
    }

    @Override
    public void depositar() {
        if (valor <= 0) {
            System.out.println("Digite um valor!");
        } else {
            saldo = saldo + valor;
            System.out.println("Saldo: R$" + saldo);
        }
    }

    @Override
    public void verSaldo() {
        System.out.println("Saldo: R$" + saldo);
    }

}
