public class Televisao implements ControleRemoto {

    @Override
    public void aumentarVolume() {
        System.out.println("Aumentando o volume da televisão...");
    }

    @Override
    public void diminuirVolume() {
        System.out.println("Diminuindo o volume da televisão...");
    }
}
