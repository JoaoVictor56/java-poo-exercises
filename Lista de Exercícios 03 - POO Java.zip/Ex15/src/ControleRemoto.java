public interface ControleRemoto {

    public void aumentarVolume();
    public void diminuirVolume();
}
