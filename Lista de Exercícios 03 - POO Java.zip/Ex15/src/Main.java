public class Main {
    public static void main(String[] args) {
        ControleRemoto tv = new Televisao();

        System.out.println();

        tv.aumentarVolume();
        tv.diminuirVolume();
    }
}