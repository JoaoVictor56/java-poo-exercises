public interface Voador {
    //=========|Ex10|=========
    public void voar();
}
