public interface Animal {
    //=========|Ex10|=========
    public void comer();

    //=========|Ex16|=========
    default void dormir() {
        System.out.println("Dormir");
    }
}
