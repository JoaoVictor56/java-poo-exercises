public class Main {
    public static void main(String[] args) {
        Passaro passaro = new Passaro();
        Cachorro cachorro = new Cachorro();

        System.out.println();

        //=========|Ex10|=========
        passaro.comer();
        passaro.voar();

        System.out.println();

        //=========|Ex16|=========
        cachorro.comer();
        cachorro.dormir();
    }
}