public class Cachorro implements Animal {
    //=========|Ex16|=========
    @Override
    public void comer() {
        System.out.println("Cachorro está comendo...");
    }

    //=========|Ex16|=========
    @Override
    public void dormir() {
        System.out.println("Zzz...");
    }
}
