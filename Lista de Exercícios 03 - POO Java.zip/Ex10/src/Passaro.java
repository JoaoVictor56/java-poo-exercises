public class Passaro implements Animal, Voador{
    //=========|Ex10|=========
    @Override
    public void comer() {
        System.out.println("O pássaro está comendo...");
    }

    //=========|Ex10|=========
    @Override
    public void voar() {
        System.out.println("O pássaro está voando...");
    }
}
