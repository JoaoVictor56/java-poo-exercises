public class Temperatura implements Conversor {
    private double temp;

    public Temperatura(double temp) {
        this.temp = temp;
    }

    @Override
    public void converter() {
        System.out.format("Temperatura em Celcius...: %.1fCº\n", temp);
        System.out.format("Temperatura em Fahrenheit: %.1fFº\n", (temp * 9 / 5) + 32);
    }
}
