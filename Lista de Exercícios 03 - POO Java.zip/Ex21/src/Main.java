public class Main {
    public static void main(String[] args) {
        Conversor temp = new Temperatura(18.5);

        System.out.println();

        temp.converter();
    }
}