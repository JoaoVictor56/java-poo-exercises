public interface Conversor {
    public void converter();
}
