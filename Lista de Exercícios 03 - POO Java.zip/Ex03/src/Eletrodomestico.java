public interface Eletrodomestico {

    //=========|Ex03|=========
    public void ligar();
    public void desligar();

    //=========|Ex20|=========
    default void verificarEstado() {

    }
}
