public class Main {
    public static void main(String[] args) {
        Eletrodomestico geladeira = new Geladeira();
        Eletrodomestico televisao = new Televisao();
        Eletrodomestico microondas = new Microondas();

        System.out.println();

        //=========|Ex03|=========
        geladeira.ligar();
        geladeira.desligar();

        System.out.println();

        televisao.ligar();
        televisao.desligar();

        System.out.println();

        //=========|Ex20|=========
        microondas.verificarEstado();
    }
}