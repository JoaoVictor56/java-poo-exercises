public class Televisao implements Eletrodomestico {

    //=========|Ex03|=========
    @Override
    public void ligar() {
        System.out.println("Ligando a televisão...");
    }

    @Override
    public void desligar() {
        System.out.println("Desligando a televisão...");
    }
}
