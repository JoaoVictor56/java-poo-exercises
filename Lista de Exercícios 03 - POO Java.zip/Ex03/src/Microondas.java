public class Microondas implements Eletrodomestico{
    //=========|Ex20|=========
    @Override
    public void ligar() {
        System.out.println("Ligando microondas...");
    }

    @Override
    public void desligar() {
        System.out.println("Desligando microondas");
    }

    @Override
    public void verificarEstado() {
        System.out.println("Estadodo microondas: Novo");
    }
}
