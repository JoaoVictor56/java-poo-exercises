public class CalculadoraCientifica implements OperacoesMatematicas {
    //=========|Ex19|=========
    private int n1;
    private int n2;

    public CalculadoraCientifica(int n1, int n2) {
        this.n1 = n1;
        this.n2 = n2;
    }

    @Override
    public void somar() {
        System.out.format("Resultado da soma.........: %d\n", n1 + n2);
    }

    @Override
    public void subtrair() {
        System.out.format("Resultado da subtração....: %d\n", n1 - n2);
    }

    @Override
    public void multiplicar() {
        System.out.format("Resultado da multiplicação: %d\n", n1 * n2);
    }

    @Override
    public void dividir() {
        System.out.format("Resultado da divisão......: %d\n", n1 / n2);
    }

    @Override
    public void potencia() {
        System.out.format("Resultado da potenciação..: %.0f\n", Math.pow(n1, n2));
    }
}
