public class Main {
    public static void main(String[] args) {
        OperacoesMatematicas calculadora  = new Calculadora(10, 2);
        OperacoesMatematicas calculadoraCientifica= new CalculadoraCientifica(10, 2);

        System.out.println();

        //=========|Ex08|=========
        calculadora.somar();
        calculadora.subtrair();
        calculadora.multiplicar();
        calculadora.dividir();

        //=========|Ex19|=========

        System.out.println();

        calculadoraCientifica.potencia();
    }
}