public interface OperacoesMatematicas {

    //=========|Ex08|=========
    public void somar();
    public void subtrair();
    public void multiplicar();
    public void dividir();

    //=========|Ex19|=========
    default void potencia(){}
}
