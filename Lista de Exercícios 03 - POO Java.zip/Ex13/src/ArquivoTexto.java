public class ArquivoTexto implements Armazenavel {

    @Override
    public void salvar() {
        System.out.println("Salvando o arquivo de texto...");
    }

    @Override
    public void carregar() {
        System.out.println("Carregando o arquivo de texto...");
    }
}
