public class BancoDeDados implements Armazenavel {

    @Override
    public void salvar() {
        System.out.println("Salvando o arquivo no banco de dados...");
    }

    @Override
    public void carregar() {
        System.out.println("Carregando o arquivo do banco de dados...");
    }
}
