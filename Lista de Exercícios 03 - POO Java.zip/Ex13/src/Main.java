public class Main {
    public static void main(String[] args) {
        Armazenavel txt = new ArquivoTexto();
        Armazenavel db = new BancoDeDados();

        System.out.println();

        txt.salvar();
        txt.carregar();

        System.out.println();

        db.salvar();
        db.carregar();
    }
}