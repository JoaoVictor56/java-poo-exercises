public interface Armazenavel {
    public void salvar();
    public void carregar();
}
