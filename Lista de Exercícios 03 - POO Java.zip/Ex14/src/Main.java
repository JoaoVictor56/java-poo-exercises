public class Main {
    public static void main(String[] args) {
        Sensores temperatura = new SensorTemperatura();
        Sensores pressao = new SensorPressao();

        System.out.println();

        temperatura.medirTemperatura();
        pressao.medirTemperatura();

    }
}