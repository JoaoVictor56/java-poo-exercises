public class SensorTemperatura implements Sensores {
    @Override
    public void medirTemperatura() {
        System.out.println("Medindo a temperatura do sensor...");
    }
}
