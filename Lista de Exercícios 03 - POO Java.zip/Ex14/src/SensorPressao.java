public class SensorPressao implements Sensores {

    @Override
    public void medirTemperatura() {
        System.out.println("Medindo a pressão do sensor...");
    }
}
