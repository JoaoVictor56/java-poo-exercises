public interface Sensores {
    public void medirTemperatura();
}
