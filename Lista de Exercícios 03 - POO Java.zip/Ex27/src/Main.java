public class Main {
    public static void main(String[] args) {
        Autenticavel user = new UsuarioSistema();
        Autenticavel admin = new Administrador();

        System.out.println();

        user.login();
        user.logout();

        System.out.println();

        admin.login();
        admin.logout();
    }
}