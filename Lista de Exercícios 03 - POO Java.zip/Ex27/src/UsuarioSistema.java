public class UsuarioSistema implements Autenticavel {

    @Override
    public void login() {
        System.out.println("Usuário fazendo o login no sistema...");
    }

    @Override
    public void logout() {
        System.out.println("Usuário fazendo o logout no sistema...");
    }
}
