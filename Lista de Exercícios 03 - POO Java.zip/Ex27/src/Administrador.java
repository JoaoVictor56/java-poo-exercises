public class Administrador implements Autenticavel {

    @Override
    public void login() {
        System.out.println("Administrador fazendo o login no sistema...");
    }

    @Override
    public void logout() {
        System.out.println("Administrador fazendo o logout no sistema...");
    }
}
