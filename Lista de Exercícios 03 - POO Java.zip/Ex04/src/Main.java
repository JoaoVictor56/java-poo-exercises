public class Main {
    public static void main(String[] args) {
        FormaGeometrica quadrado = new Quadrado(10);
        FormaGeometrica circulo = new Circulo(6);

        System.out.println();

        quadrado.calcularArea();
        circulo.calcularArea();

        System.out.println();
    }
}