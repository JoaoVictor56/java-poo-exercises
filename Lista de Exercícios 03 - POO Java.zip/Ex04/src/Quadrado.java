public class Quadrado implements FormaGeometrica {
    private int lado;

    public Quadrado(int lado) {
        this.lado = lado;
    }

    @Override
    public void calcularArea() {
        System.out.println("Área do Quadrado: " + Math.pow(lado, 2));
    }
}
