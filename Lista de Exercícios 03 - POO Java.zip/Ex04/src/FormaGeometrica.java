public interface FormaGeometrica {
    public void calcularArea();
}
