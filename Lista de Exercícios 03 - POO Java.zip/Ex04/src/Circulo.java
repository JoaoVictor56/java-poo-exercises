public class Circulo implements FormaGeometrica {
    private int raio;

    public Circulo(int raio) {
        this.raio = raio;
    }

    @Override
    public void calcularArea() {
        System.out.format("Área do Círculo.: %.2f", Math.PI * Math.pow(raio, 2));
    }
}
