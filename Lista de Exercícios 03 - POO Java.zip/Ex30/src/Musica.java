public interface Musica {
    public void play();
    public void pause();
    public void stop();
}
