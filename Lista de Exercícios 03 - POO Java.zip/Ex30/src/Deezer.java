public class Deezer implements Musica {

    @Override
    public void play() {
        System.out.println("Música do Deezer iniciada!");
    }

    @Override
    public void pause() {
        System.out.println("Música do Deezer pausada!");
    }

    @Override
    public void stop() {
        System.out.println("Encerrando o Deezer...");
    }
}
