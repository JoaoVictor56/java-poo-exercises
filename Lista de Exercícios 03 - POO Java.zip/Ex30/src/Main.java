public class Main {
    public static void main(String[] args) {
        Musica spotify = new Spotify();
        Musica deezer = new Deezer();

        System.out.println();

        spotify.play();
        spotify.pause();
        spotify.stop();

        System.out.println();

        deezer.play();
        deezer.pause();
        deezer.stop();
    }
}