public class Spotify implements Musica {

    @Override
    public void play() {
        System.out.println("Música no Spotify iniciada!");
    }

    @Override
    public void pause() {
        System.out.println("Música do Spotify pausada!");
    }

    @Override
    public void stop() {
        System.out.println("Encerrando o Spotify...");
    }
}
