public interface Mensagem {

     public void mensagem();
}
