public class Usuario implements Mensagem {

    @Override
    public void mensagem() {
        System.out.println("Seja bem-vindo ao sistema!");
    }
}
