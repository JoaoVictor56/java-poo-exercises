public class Main {
    public static void main(String[] args) {
        Mensagem user = new Usuario();

        System.out.println();

        user.mensagem();
    }
}