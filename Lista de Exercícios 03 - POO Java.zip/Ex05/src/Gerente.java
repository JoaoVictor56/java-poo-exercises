public class Gerente implements Funcionario {

    @Override
    public void calcularSalario() {
        System.out.println("Salário do gerente....: R$35000");
    }
}
