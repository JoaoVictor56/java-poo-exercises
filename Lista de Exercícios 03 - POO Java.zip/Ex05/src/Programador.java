public class Programador implements Funcionario {
    @Override
    public void calcularSalario() {
        System.out.println("Salário do programador: R$6000");
    }
}
