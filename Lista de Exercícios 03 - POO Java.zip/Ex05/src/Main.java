public class Main {
    public static void main(String[] args) {
        Funcionario gerente = new Gerente();
        Funcionario programador = new Programador();

        System.out.println();

        gerente.calcularSalario();
        programador.calcularSalario();
    }
}