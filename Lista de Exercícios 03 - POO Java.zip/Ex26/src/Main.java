public class Main {
    public static void main(String[] args) {
        //=========|Exemplo 01|=========
        Transmissivel youtube = new Youtube();
        Transmissivel twitch = new Twitch();

        youtube.iniciarTransmissao();
        youtube.finalizarTransmissao();

        System.out.println();
        
        twitch.iniciarTransmissao();
        twitch.finalizarTransmissao();
    }
}