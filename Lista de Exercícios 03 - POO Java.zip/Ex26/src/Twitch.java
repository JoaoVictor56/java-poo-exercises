public class Twitch implements Transmissivel {

    @Override
    public void iniciarTransmissao() {
        System.out.println("Iniciando transmissão na Twitch");
    }

    @Override
    public void finalizarTransmissao() {
        System.out.println("Finalizando transmissão na Twitch");
    }
}
