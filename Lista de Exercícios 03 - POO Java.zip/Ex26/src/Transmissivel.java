public interface Transmissivel {
    public void iniciarTransmissao();
    public void finalizarTransmissao();
}
