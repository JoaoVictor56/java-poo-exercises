public class Youtube implements Transmissivel {
    @Override
    public void iniciarTransmissao() {
        System.out.println("Iniciando transmissão no Youtube...");
    }

    @Override
    public void finalizarTransmissao() {
        System.out.println("Finalizando transmissão no Youtube...");
    }
}
