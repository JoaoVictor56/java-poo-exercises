public class Pessoa {
    private String nome;
    private String email;
    private int idade;
    private String tipo;

    Pessoa(String nome, String email, int idade, String tipo) {
        this.nome = nome;
        this.email = email;
        this.idade = idade;
        this.tipo = tipo;
    }

    public void exibirInfo() {
        IO.println("Nome..............: " + nome);
        IO.println("Tipo..............: " + tipo);
        IO.println("Email.............: " + email);
        IO.println("Idade.............: " + idade);
    }
}
