public class Professor extends Pessoa {
    private double salario;
    private int id;
    private String formacaoAcademica;

    Professor(String nome, String email, int idade, String tipo, double salario, int id, String formacaoAcademica) {
        super(nome, email, idade, tipo);
        this.salario = salario;
        this.id = id;
        this.formacaoAcademica = formacaoAcademica;
    }

    public void exibirProfessor() {
        IO.println("Salario...........: " + salario);
        IO.println("ID................: " + id);
        IO.println("Formação Acadêmica: " + formacaoAcademica);
    }
}
