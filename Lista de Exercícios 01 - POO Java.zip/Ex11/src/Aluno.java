public class Aluno extends Pessoa {
    private int id;
    private String curso;

    Aluno(String nome, String email, int idade, String tipo, int id, String curso) {
        super(nome, email, idade, tipo);
        this.id = id;
        this.curso = curso;
    }

    public void exibirAluno() {
        IO.println("ID................: " + id);
        IO.println("Curso.............: " + curso);
    }

}
