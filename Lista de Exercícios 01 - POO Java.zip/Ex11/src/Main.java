void main() {
    Professor professor = new Professor("Fabricio","fabricio@gmail.com", 30, "Professor", 3500, 10, "Analise e Desenvolvimento de Sistemas");
    Aluno aluno = new Aluno("João", "joao@gmail.com", 18, "Aluno",252657, "Engenharia de Software");

    IO.println("\n");

    IO.println("Professor");
    professor.exibirInfo();
    professor.exibirProfessor();

    IO.println("\n");

    IO.println("Aluno");
    aluno.exibirInfo();
    aluno.exibirAluno();

}