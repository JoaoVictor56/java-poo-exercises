public class Produto {
    String nome;
    int quantidade;
    float preco;
    float valorTotal;

    public void calculaValor() {
        valorTotal = quantidade * preco;
    }

    public void exibirValor() {
        IO.println("Nome........: " + nome);
        IO.println("Qtd. Produto: " + quantidade);
        IO.println("R$ Produto..: " + preco);
        IO.println("R$ Produto..: " + valorTotal);
    }
}
