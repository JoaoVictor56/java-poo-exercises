import java.util.Scanner;

void main() {
    Produto produto = new Produto();
    Scanner scanner = new Scanner(System.in);

    IO.println("Digite o nome do produto......: ");
    produto.nome = scanner.nextLine();

    IO.println("Digite a quantidade do produto: ");
    produto.quantidade = scanner.nextInt();

    IO.println("Digite o valor do produto.....: ");
    produto.preco = scanner.nextFloat();

    produto.calculaValor();
    produto.exibirValor();
}