void main() {
    Cachorro dog = new Cachorro();
    Gato cat = new Gato();

    emitirSomAnimal(dog);
    emitirSomAnimal(cat);

}

public static void emitirSomAnimal(Animal animal) {
    animal.emitirSom();
}