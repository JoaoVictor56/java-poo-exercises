public class Carro {
    //Declaração de atributos
    private String modelo;

    //Construtor
    Carro(String modelo) {
        this.modelo = modelo;
    }

    //Getter
    public String getModelo() {
        return modelo;
    }
}
