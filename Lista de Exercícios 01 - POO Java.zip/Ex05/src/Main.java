void main() {
    //Criação de objetos
    Carro carrinho = new Carro("Honda Civic 2020");
    Dono adm = new Dono("João", carrinho);

    //Exibe as informações
    adm.exibirInfo();
}