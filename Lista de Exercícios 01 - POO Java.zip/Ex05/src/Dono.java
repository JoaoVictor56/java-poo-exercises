public class Dono {
    //Declaração de atributos
    private String nomeDono;
    private Carro carro;

    //Construtor
    Dono(String nomeDono, Carro carro) {
        this.nomeDono = nomeDono;
        this.carro = carro;
    }

    //Metodo para exibir as informações
    public void exibirInfo() {
        IO.println("Dono.: " + nomeDono);
        IO.println("Carro: " + carro.getModelo());
    }
}
