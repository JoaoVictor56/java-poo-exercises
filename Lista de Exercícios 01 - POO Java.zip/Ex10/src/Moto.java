public class Moto extends Veiculo {
    private int cilindrada;

    public Moto(String marca, int cilindrada) {
        super(marca);
        this.cilindrada = cilindrada;
    }

    public void exibirInformacoes() {
        IO.println("Marca da moto: " + getMarca());
        IO.println("Cilindrada...: " + cilindrada + "cc");
    }

}
