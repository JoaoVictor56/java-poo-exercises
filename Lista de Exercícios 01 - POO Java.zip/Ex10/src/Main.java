void main() {
    Moto moto = new Moto("Yamaha", 155);

    moto.exibirInformacoes();
}