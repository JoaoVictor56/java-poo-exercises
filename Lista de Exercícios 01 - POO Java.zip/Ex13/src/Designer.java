public class Designer extends Empregado {

    public void exibir() {
        IO.println("Designer");
    }
}
