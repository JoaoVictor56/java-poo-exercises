public class Programador extends Empregado {

    public void exibir() {
        IO.println("Programador");
    }
}
