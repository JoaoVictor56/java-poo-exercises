public class Empregado {

    public void exibir() {
        IO.println("Empregado");
    }
}
