void main() {
    Empregado empregado = new Empregado();
    Programador programador = new Programador();
    Designer designer = new Designer();

    empregado.exibir();
    programador.exibir();
    designer.exibir();
}