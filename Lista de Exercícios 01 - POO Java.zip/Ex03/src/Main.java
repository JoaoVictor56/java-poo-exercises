import java.util.Scanner;

void main() {
    Pessoa pessoa = new Pessoa();
    Scanner scan = new Scanner(System.in);

    IO.println("Digite o seu nome: ");
    pessoa.nome = scan.nextLine();

    IO.println("Digite sua idade: ");
    pessoa.idade = scan.nextInt();

    pessoa.verificaIdade();
}