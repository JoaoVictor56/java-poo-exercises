public class Pessoa {
    String nome;
    int idade;

    public void verificaIdade() {
        if (idade < 18) {
            System.out.format("\n%s é menor de idade\n", nome);
            IO.println("+--------------------------------------+------------+");
            System.out.format("| Nome: %-30s | Idade: %3d |\n", nome, idade);
            IO.println("+--------------------------------------+------------+");
        } else {
            System.out.format("\n%s é maior de idade\n", nome);
            IO.println("+--------------------------------------+------------+");
            System.out.format("| Nome: %-30s | Idade: %3d |\n", nome, idade);
            IO.println("+--------------------------------------+------------+");
        }
    }
}
