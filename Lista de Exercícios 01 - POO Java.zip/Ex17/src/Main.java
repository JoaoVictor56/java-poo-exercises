void main() {
    Cachorro dog = new Cachorro();
    Gato cat = new Gato();

    dog.emitirSom();
    cat.emitirSom();
}