public class Carro extends Veiculo {
    @Override
    public void abastecer() {
        System.out.println("Abastecendo com gasolina");
    }
}
