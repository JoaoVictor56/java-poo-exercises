public class CarroEletrico extends Carro {
    @Override
    public void abastecer() {
        System.out.println("Recarregando a bateria");
    }
}
