public class Veiculo {
    public void abastecer() {
        System.out.println("Abastecendo");
    }
}
