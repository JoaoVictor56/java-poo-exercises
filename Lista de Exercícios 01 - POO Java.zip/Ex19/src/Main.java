void main() {
    Veiculo veiculo = new Veiculo();
    Carro carro = new Carro();
    CarroEletrico carroEletrico = new CarroEletrico();

    veiculo.abastecer();
    carro.abastecer();
    carroEletrico.abastecer();
}