void main() {
    //Crição de Objetos
    Carro c1 = new Carro("Ford", "Fusion", 2006);
    Carro c2 = new Carro("Audi", "A4", 2016);
    Carro c3 = new Carro("Chevrolet", "Corsa", 2002);
    Carro c4 = new Carro("BMW", "X6", 2026);
    Carro c5 = new Carro("Volkswagen", "Virtus", 2020);

    IO.println("+---------------------+--------------------+-----------+");
    c1.exibirDetalhes();
    c2.exibirDetalhes();
    c3.exibirDetalhes();
    c4.exibirDetalhes();
    c5.exibirDetalhes();
    IO.println("+---------------------+--------------------+-----------+");

    Carro.exibeCarros();
    IO.println("+------------------------------------------------------+");
}