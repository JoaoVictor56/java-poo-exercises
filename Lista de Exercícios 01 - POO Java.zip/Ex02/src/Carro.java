public class Carro {
    //Declaração de atributos
    private String marca;
    private String modelo;
    private int ano;
    private static int contador = 0;

    //Construtor
    public Carro(String Marca, String Modelo, int Ano) {
        this.marca = Marca;
        this.modelo = Modelo;
        this.ano = Ano;
        contador++;
    }

    //Metodo exibirDetalhes()
    public void exibirDetalhes() {
        System.out.format("| Marca: %-12s | Modelo: %-10s | Ano: %4d |", marca, modelo, ano);
        System.out.println();
    }

    //Getter e Setter(marca)
    public String getMarca() {
        return marca;
    }
    public void setMarca(String Marca) {
        this.marca = Marca;
    }

    //Getter e Setter (modelo)
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String Modelo) {
        this.modelo = Modelo;
    }

    //Getter e Setter (ano)
    public int getAno() {
        return ano;
    }
    public void setAno(int Ano) {
        this.ano = Ano;
    }

    //Contador
    public static void exibeCarros() {
        System.out.println("| Quantidade total de carros: " + contador + "                        |");
    }
}