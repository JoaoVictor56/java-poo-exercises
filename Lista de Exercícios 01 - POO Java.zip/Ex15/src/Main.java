void main() {
    Animal animal = new Animal();
    Cachorro cachorro = new Cachorro();
    Gato gato = new Gato();

    animal.emitirSom();
    cachorro.emitirSom();
    gato.emitirSom();
}