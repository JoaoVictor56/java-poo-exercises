void main() {
    ContaBancaria conta = new ContaBancaria();
    Scanner scan = new Scanner(System.in);

    int escolha;

    conta.mostrarSaldo();
    IO.println("1. Sacar");
    IO.println("2. Depositar");

    do {
        IO.println("Qual ação deseja realizar?: ");
        escolha = scan.nextInt();

        switch (escolha) {
            case 1:
                conta.sacar();
                break;

            case 2:
                conta.depositar();
                break;

            default:
                break;
        }
    } while (escolha != 1 && escolha != 2);
}