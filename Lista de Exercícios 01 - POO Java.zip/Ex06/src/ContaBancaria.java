import java.util.Scanner;

public class ContaBancaria {
    Scanner scan = new Scanner(System.in);
    private float valorSaldo = 10;
    private float valorDoSaque;
    private float valorDoDeposito;

    public void mostrarSaldo() {
        IO.println("Saldo: R$" + valorSaldo);
    }

    public void sacar() {
        do {
            IO.println("Digite o valor que deseja sacar: R$");
            valorDoSaque = scan.nextFloat();

            if (valorDoSaque > valorSaldo) {
                IO.println("Valor insuficiente. Tente novamente!");
            } else {
                valorSaldo = valorSaldo - valorDoSaque;
                mostrarSaldo();
            }
        } while (valorDoSaque > valorSaldo);
    }

    public void depositar() {
        do {
            IO.println("Digite o valor que deseja depositar: R$");
            valorDoDeposito = scan.nextFloat();

            if (valorDoDeposito <= 0) {
                IO.println("Valor insuficiente. Tente novamente!");
            } else {
                valorSaldo = valorSaldo + valorDoDeposito;
                mostrarSaldo();
            }
        } while (valorDoDeposito <= 0);
    }
}
