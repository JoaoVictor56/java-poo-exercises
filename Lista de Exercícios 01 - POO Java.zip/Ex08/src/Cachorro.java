public class Cachorro extends Animal{

    Cachorro(String nome, int idade) {
        super(nome, idade);
    }

    public void latir() {
        IO.println("Latido");
    }
}
