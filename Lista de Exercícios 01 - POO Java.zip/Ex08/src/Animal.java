public class Animal {
    String nome;
    int idade;

    //Construtor (nome e idade)
    Animal(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    //Construtor (padrão)
    Animal() {
        this.nome = "N/A";
        this.idade = 0;
    }

    //Construtor (nome)
    Animal(String nome) {
        this.nome = nome;
        this.idade = 0;
    }

    public void mostrarInfo() {
        IO.println("Nome.: " + nome);
        IO.println("Idade: " + idade);
        IO.println("\n");
    }
}
