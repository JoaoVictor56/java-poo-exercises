void main() {
    Animal animal1 = new Animal("Ranger", 3);
    Animal animal2 = new Animal("Bob");
    Animal animal3 = new Animal();

    animal1.mostrarInfo();
    animal2.mostrarInfo();
    animal3.mostrarInfo();
}