public class Gato extends Animal {

    Gato(String nome, int idade) {
        super(nome, idade);
    }

    public void miar() {
        IO.println("Miado");
    }
}
