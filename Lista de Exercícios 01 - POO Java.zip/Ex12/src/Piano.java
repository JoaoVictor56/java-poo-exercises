public class Piano extends InstrumentoMusical {

    public void tocar() {
        IO.println("Som de piano");
    }
}
