public class Violao extends InstrumentoMusical {

    public void tocar() {
        IO.println("Som de violão");
    }
}
