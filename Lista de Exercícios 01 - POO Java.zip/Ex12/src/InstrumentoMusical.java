public class InstrumentoMusical {
    public void tocar() {
        IO.println("som genérico");
    }
}
