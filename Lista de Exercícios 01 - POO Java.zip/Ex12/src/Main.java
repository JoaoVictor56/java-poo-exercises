void main() {
    InstrumentoMusical im = new InstrumentoMusical();
    Piano piano = new Piano();
    Violao violao = new Violao();

    im.tocar();
    piano.tocar();
    violao.tocar();
}