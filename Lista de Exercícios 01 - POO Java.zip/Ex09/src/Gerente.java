public class Gerente extends Funcionario {
    private double salarioFinal;

    Gerente(String nome, double salario) {
        super(nome, salario);
    }

    @Override
    public double getBonificacao() {
        return super.getBonificacao() + 200.00;
    }
}