void main() {
    Funcionario f = new Funcionario("João", 2000);
    Gerente g = new Gerente("Maria", 5000);

    IO.println("Nome: " + f.getNome() + "  " + "Salario: R$" + f.getSalario());
    IO.println("Nome: " + g.getNome() + "  " + "Salario: R$" + g.getBonificacao());
}